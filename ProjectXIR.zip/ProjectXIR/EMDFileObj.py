import traceback
from typing import *
from fileUtil import *
import numpy as np
import time
import multiprocessing as mp


class EmdModel:
    def __init__(self):
        self.name = None
        self.groups = [] #type: List[EmdGroup]

class EmdGroup:
    def __init__(self,group_name):
        self.name = group_name
        self.subMeshes = []
        self.meshes = []  # type: List[EmdMesh]
        self.meshCount = 0

class EmdMesh:
    def __init__(self):
        self.MeshName           = ''                #type: str
        self.vertexes           = VertexCloud()     #type: VertexCloud
        self.vertices           = []                #type: List[EMDVertex]
        self.faces              = []                #type: List[np.uint32]
        self.edges              = []                #type: List[Set[int,int]]
        self.UVs                = []                #type: List[Set[float,float]]
        self.normals            = []                #type: List[Set[float,float,float]]
        self.vertex_group_names = []                #type: List[str]
        self.vertex_groups      = {}                #type: Dict[('*VGName*',List[Vertex])]
        self.color_ramp         = None              #type:
        self.details            = None              #type:
        self.average_center     = []                #type: List[float,float,float]

    def create_edges(self, faceList):
        edgeList = []
        for i in faceList:
            edgeList.append(tuple((i[0], i[1])))
            edgeList.append(tuple((i[0], i[2])))
            edgeList.append(tuple((i[1], i[2])))
        self.edges = edgeList

class Vertex:
    def __init__(self):
        self.location       = [0.0, 0.0, 0.0]   ##type: List[float,float,float]
        self.normal         = [0.0, 0.0, 0.0]   ##type: List[float,float,float]
        self.weight         = 0.0               ##type: float
        self.UV             = [0.0, 0.0]        ##type: List[float,float]
        self.vertex_groups  = {}                ##type: {'VGName 1': float,'VGName 2': float,'VGName 3': float,'VGName 4': float}
        self.boneGroup      = 0

class EMD:
    def __init__(self,Hexadecimal):
        self.Header       = EMD_Header(Hexadecimal)

        self.Section      = EMD_Section(Hexadecimal)
        #print('Model Count:', self.Section.number_models)

        #startTime = time.process_time()
        self.Models       = [Model_Section(Hexadecimal[
                                          self.Section.mod_pointers[ind]:],
                                          self.Section.mod_names[ind])
                            for ind in range(0,self.Section.number_models)]
        #print('Models elapsed Time:',time.process_time() - startTime)

        self.Meshes       = [ind.meshes for ind in self.Models] #[[Mesh_Section(mesh) for mesh in self.Models[model].meshHexes] for model in range(0,self.Section.number_models)]

        self.SubMeshes    = []
        for mes in self.Meshes:
            SubList  = [ind.subMeshes for ind in mes]
            #print(len(SubList))
            self.SubMeshes.append(SubList)
        #for oof in self.SubMeshes:
        #    print(oof)

        self.TextureDefs  = []
        for mesh in self.SubMeshes:
            for sub in mesh:
                for tex in sub:
                    self.TextureDefs.append(tex.TextureDefs)
            
            

        self.Triangles    = []
        for sub in self.SubMeshes:
            TriList = [[ind2.Triangles for ind2 in ind] for ind in sub]
            #print('TriList Len',len(TriList))
            self.Triangles.append(TriList)


        self.Vertices     = []
        for sub in self.SubMeshes:
            VertList = [[ind2.Verts for ind2 in ind] for ind in sub]
            #print('VertList Len',len(VertList))
            self.Vertices.append(VertList)
        #print('Mesh Names:',[[[name.name for name in MeshLib] for MeshLib in SubmeshLib] for SubmeshLib in self.SubMeshes])
        #print('TriaClusters Lens:', [[len(oof2) for oof2 in oof] for oof in self.Triangles])
        #print('VertClusters Lens:',[[len(oof2) for oof2 in oof] for oof in self.Vertices])


class EMD_Header:
    def __init__(self,hexList):
        self.signature       = hex2str(hexList[0x00:0x04])
        self.endian          = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x04:0x06],keepSpaces=False)),np.uint16)
        self.header_size     = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x06:0x08],keepSpaces=False)),np.uint16)
        self.version         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x08:0x0c],keepSpaces=False)),np.uint8)
        self.unknow_0        = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x0c:0x10],keepSpaces=False)),np.uint32)
        pass
class EMD_Section:
    def __init__(self,hexList):
        self.unknow_0            = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x10:0x12],keepSpaces=False)),np.uint16)[0]
        self.number_models       = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x12:0x14],keepSpaces=False)),np.uint16)[0]
        self.offset_models       = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x14:0x18],keepSpaces=False)),np.uint32)[0]
        self.offset_models_name  = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x18:0x1c],keepSpaces=False)),np.uint32)[0]

        self.name_pointers = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[self.offset_models_name:self.offset_models_name + (4 * self.number_models)], keepSpaces=False)), np.uint32)
        self.mod_names = self.get_names(hexList,self.name_pointers)

        self.mod_pointers = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[self.offset_models:self.offset_models + (4 * self.number_models)], keepSpaces=False)), np.uint32)

    def get_names(self,hList,NamePointers):
        names = []
        for NameOffset in NamePointers:
            decodeThis = ''
            for hexItem in hList[NameOffset:NameOffset+hList[NameOffset:].index('00')]:
                decodeThis += hexItem
            names.append(str(bytes.fromhex(decodeThis).decode('charmap')))
        return names
class Model_Section:
    def __init__(self,hexList,Name=None):
        self.name                = Name
        self.global_Offset       = None

        self.unknow_0            = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x00:0x02],keepSpaces=False)),np.uint16)[0]
        self.number_meshs        = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x02:0x04],keepSpaces=False)),np.uint16)[0]
        self.offset_meshs        = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x04:0x08],keepSpaces=False)),np.uint32)[0]


        self.mes_pointers = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[self.offset_meshs:self.offset_meshs + (4 * self.number_meshs)],keepSpaces=False)), np.uint32)

        self.meshHexes = self.get_MeshHexes(hexList, self.mes_pointers)

        #startTime = time.process_time()
        self.meshes = [Mesh_Section(ind) for ind in self.meshHexes]
        #print('Mesh fuck:', time.process_time() - startTime)

    def get_MeshHexes(self,hList,pointers):
        ReturnMeshes = []
        for point in range(0, len(pointers)):
            if point + 1 < len(pointers):
                ReturnMeshes.append(hList[pointers[point]:pointers[point + 1]][:-1])
            else:
                ReturnMeshes.append(hList[pointers[point]:][:-1])
        return ReturnMeshes
        pass
class Mesh_Section:
    def __init__(self,hexList:list):
        self.global_Offset      = None
        self.aabb_center_x      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x00:0x04], keepSpaces=False)),np.float32)[0]
        self.aabb_center_y      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x04:0x08], keepSpaces=False)),np.float32)[0]
        self.aabb_center_z      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x08:0x0c], keepSpaces=False)),np.float32)[0]
        self.aabb_center_w      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x0c:0x10], keepSpaces=False)),np.float32)[0]
        self.aabb_min_x         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x10:0x14], keepSpaces=False)),np.float32)[0]
        self.aabb_min_y         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x14:0x18], keepSpaces=False)),np.float32)[0]
        self.aabb_min_z         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x18:0x1c], keepSpaces=False)),np.float32)[0]
        self.aabb_min_w         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x1c:0x20], keepSpaces=False)),np.float32)[0]
        self.aabb_max_x         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x20:0x24], keepSpaces=False)),np.float32)[0]
        self.aabb_max_y         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x24:0x28], keepSpaces=False)),np.float32)[0]
        self.aabb_max_z         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x28:0x2c], keepSpaces=False)),np.float32)[0]
        self.aabb_max_w         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x2c:0x30], keepSpaces=False)),np.float32)[0]
        self.offset_mesh_name   = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x30:0x34], keepSpaces=False)),np.uint32)[0]
        self.unknow_0           = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x34:0x36], keepSpaces=False)),np.uint16)[0]
        self.number_submeshs    = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x36:0x38], keepSpaces=False)),np.uint16)[0]
        self.offset_submeshs    = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x38:0x3c], keepSpaces=False)),np.uint32)[0]

        self.name = self.get_name(hexList, self.offset_mesh_name)

        self.sub_pointers = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[self.offset_submeshs:self.offset_submeshs+ (4 *self.number_submeshs)],keepSpaces=False)), np.uint32)

        self.submeshHex = self.get_subHex(hexList, self.sub_pointers)

        #subTime = time.process_time()
        self.subMeshes = [SubMesh_Section(ind) for ind in self.submeshHex]
        #print('submesh fuck:', time.process_time() - subTime)

    def get_subHex(self,hList,pointers):
        SubMeshes = []
        for k in range(0, len(pointers)):
            if k + 1 < len(pointers):
                SubMeshes.append(hList[pointers[k]:pointers[k + 1]][:-1])
            else:
                SubMeshes.append(hList[pointers[k]:][:-1])
        return SubMeshes

    def get_name(self,hList,NameOffset):
        decodeThis = ''
        for hexItem in hList[NameOffset:NameOffset+hList[NameOffset:].index('00')]:
            decodeThis += hexItem
        return str(bytes.fromhex(decodeThis).decode('charmap'))
    pass
class SubMesh_Section:
    def __init__(self,hexList):
        # print('Vertex Type Flag:', self.vertex_type_flag)
        # print('EMD_VTX_FLAG_BLEND_WEIGHT', self.vertex_type_flag & 0x200)
        
        self.global_Offset          = None
        self.aabb_center_x          = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x00:0x04], keepSpaces=False)),np.float32)[0]
        self.aabb_center_y          = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x04:0x08], keepSpaces=False)),np.float32)[0]
        self.aabb_center_z          = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x08:0x0c], keepSpaces=False)),np.float32)[0]
        self.aabb_center_w          = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x0c:0x10], keepSpaces=False)),np.float32)[0]
        self.aabb_min_x             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x10:0x14], keepSpaces=False)),np.float32)[0]
        self.aabb_min_y             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x14:0x18], keepSpaces=False)),np.float32)[0]
        self.aabb_min_z             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x18:0x1c], keepSpaces=False)),np.float32)[0]
        self.aabb_min_w             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x1c:0x20], keepSpaces=False)),np.float32)[0]
        self.aabb_max_x             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x20:0x24], keepSpaces=False)),np.float32)[0]
        self.aabb_max_y             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x24:0x28], keepSpaces=False)),np.float32)[0]
        self.aabb_max_z             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x28:0x2c], keepSpaces=False)),np.float32)[0]
        self.aabb_max_w             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x2c:0x30], keepSpaces=False)),np.float32)[0]
        self.vertex_type_flag       = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x30:0x34], keepSpaces=False)),np.uint32)[0]
        

        self.vertex_size            = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x34:0x38], keepSpaces=False)),np.uint32)[0]
        self.number_vertex          = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x38:0x3c], keepSpaces=False)),np.uint32)[0]
        self.offset_vertex          = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x3c:0x40], keepSpaces=False)),np.uint32)[0]
        self.offset_submesh_name    = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x40:0x44], keepSpaces=False)),np.uint32)[0]
        self.unknow_0               = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x44:0x45], keepSpaces=False)),np.uint8)[0]
        self.number_textureDef      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x45:0x46], keepSpaces=False)),np.uint8)[0]
        self.number_triangles       = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x46:0x48], keepSpaces=False)),np.uint16)[0]
        self.offset_textureDef      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x48:0x4c], keepSpaces=False)),np.uint32)[0]
        self.offset_triangles       = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x4c:0x50], keepSpaces=False)),np.uint32)[0]

        print(tuple([0x00, 0x04]), "\t\taabb_center_x\t\t",   self.aabb_center_x,       "\t",       hexList[0x00:0x04])
        print(tuple([0x04, 0x08]), "\t\taabb_center_y\t\t",   self.aabb_center_y,       "\t",       hexList[0x04:0x08])
        print(tuple([0x08, 0x0c]), "\taabb_center_z\t\t",     self.aabb_center_z,       "\t",       hexList[0x08:0x0c])
        print(tuple([0x0c, 0x10]), "\taabb_center_w\t\t",     self.aabb_center_w,       "\t",       hexList[0x0c:0x10])
        print(tuple([0x10, 0x14]), "\taabb_min_x\t\t\t",      self.aabb_min_x,          "\t",       hexList[0x10:0x14])
        print(tuple([0x14, 0x18]), "\taabb_min_y\t\t\t",      self.aabb_min_y,          "\t",       hexList[0x14:0x18])
        print(tuple([0x18, 0x1c]), "\taabb_min_z\t\t\t",      self.aabb_min_z,          "\t",       hexList[0x18:0x1c])
        print(tuple([0x1c, 0x20]), "\taabb_min_w\t\t\t",      self.aabb_min_w,          "\t",       hexList[0x1c:0x20])
        print(tuple([0x20, 0x24]), "\taabb_max_x\t\t\t",      self.aabb_max_x,          "\t",       hexList[0x20:0x24])
        print(tuple([0x24, 0x28]), "\taabb_max_y\t\t\t",      self.aabb_max_y,          "\t\t",     hexList[0x24:0x28])
        print(tuple([0x28, 0x2c]), "\taabb_max_z\t\t\t",      self.aabb_max_z,          "\t",       hexList[0x28:0x2c])
        print(tuple([0x2c, 0x30]), "\taabb_max_w\t\t\t",      self.aabb_max_w,          "\t",       hexList[0x2c:0x30])
        print(tuple([0x30, 0x34]), "\tvertex_type_flag\t",    self.vertex_type_flag,    "\t\t\t",   hexList[0x30:0x34])
        print(tuple([0x34, 0x38]), "\tvertex_size\t\t\t",     self.vertex_size,         "\t\t\t",   hexList[0x34:0x38])
        print(tuple([0x38, 0x3c]), "\tnumber_vertex\t\t",     self.number_vertex,       "\t\t\t",   hexList[0x38:0x3c])
        print(tuple([0x3c, 0x40]), "\toffset_vertex\t\t",     self.offset_vertex,       "\t\t\t",   hexList[0x3c:0x40])
        print(tuple([0x40, 0x44]), "\toffset_submesh_name\t", self.offset_submesh_name, "\t\t\t",   hexList[0x40:0x44])
        print(tuple([0x44, 0x45]), "\tunknow_0\t\t\t",        self.unknow_0,            "\t\t\t\t", hexList[0x44:0x45])
        print(tuple([0x45, 0x46]), "\tnumber_textureDef\t",   self.number_textureDef,   "\t\t\t\t", hexList[0x45:0x46])
        print(tuple([0x46, 0x48]), "\tnumber_triangles\t",    self.number_triangles,    "\t\t\t\t", hexList[0x46:0x48])
        print(tuple([0x48, 0x4c]), "\toffset_textureDef\t",   self.offset_textureDef,   "\t\t\t",   hexList[0x48:0x4c])
        print(tuple([0x4c, 0x50]), "\toffset_triangles\t",    self.offset_triangles,    "\t\t\t",   hexList[0x4c:0x50])
        print()
        
        self.name = self.get_name(hexList,self.offset_submesh_name)
        
        self.tri_pointers = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[self.offset_triangles:self.offset_triangles+ (4 * self.number_triangles)],keepSpaces=False)), np.uint32)
        self.TriHex = self.get_TriHex(hexList,self.tri_pointers)
        
        
        print(self.offset_textureDef)
        print(hexList[self.offset_textureDef:self.offset_textureDef+12])
        
        print(hexList[self.offset_textureDef:self.offset_textureDef+ (2 * self.number_textureDef)])
        self.tex_pointers = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[self.offset_textureDef:self.offset_textureDef+ (2 * self.number_textureDef)],keepSpaces=False)), np.uint16)
        print(self.tex_pointers)
        self.TexHex = self.get_TexHex(hexList,self.tex_pointers)
        

        self.Triangles = [EMDTriangles_Section(tri) for tri in self.TriHex]
        self.TextureDefs = [EMDTextureDef_Section(tex) for tex in self.TexHex]
        self.Verts = [EMDVertex(hexList[self.offset_vertex:][line * 36:]) for line in range(0, self.number_vertex)]
        
        
    def get_TriHex(self,hList, pointers:list):
        Triangles = []
        print("Tri Hex:",hList[:20])
        for pointer in range(0, len(pointers)):
            if pointer + 1 < len(pointers):
                Triangles.append(
                    hList[pointers[pointer]:pointers[pointer + 1]][:-1])
            else:
                Triangles.append(hList[pointers[pointer]:][:-1])
        return Triangles

    def get_TexHex(self,hList,pointers:list):
        Textures = []
        print("Tex Hex:",hList[:20])
        for point in range(0, len(pointers)):
            print(pointers[point])
            if point + 1 < len(pointers):
                Textures.append(hList[pointers[point]:pointers[point + 1]][:-1])
            else:
                Textures.append(hList[pointers[point]:][:-1])
        return Textures

    def get_name(self,hList,NameOffset):
        decodeThis = ''
        for hexItem in hList[NameOffset:NameOffset+hList[NameOffset:].index('00')]:
            decodeThis += hexItem
        return str(bytes.fromhex(decodeThis).decode('charmap'))
    pass

class EMDVertex:
    def __init__(self,vL: list):

        self.location = np.frombuffer(bytes.fromhex(hexList2hexStrList(vL[0:12], keepSpaces=False)),np.float32)
        self.normal = np.frombuffer(bytes.fromhex(hexList2hexStrList(vL[12:18], keepSpaces=False)),np.float16)
        UV_Temp = np.frombuffer(bytes.fromhex(hexList2hexStrList(vL[20:24], keepSpaces=False)),np.float16)
        self.UV = [UV_Temp[0],-1*UV_Temp[1]]
        self.vgIndexes = np.frombuffer(bytes.fromhex(hexList2hexStrList(vL[24:28], keepSpaces=False)),np.uint8)
        self.vgNames = []
        self.weights = self.solve_weights(vL)
        #print()
        #print([[self.vgIndexes[i],self.weights[i]] for i in range(0,4)])




    def solve_weights(self, vLine):
        blends = np.frombuffer(bytes.fromhex(hexList2hexStrList(vLine[28:34], keepSpaces=False)), np.float16)
        weight_4 = 1 - (blends[2] + blends[1] + blends[0])
        weight_1 = blends[0]
        weight_2 = blends[1]
        weight_3 = 1 - (weight_4 + weight_2 + weight_1)
        return np.array([weight_1, weight_2, weight_3, weight_4])
        pass

class EMDTextureDef_Section:
    def __init__(self,hexList):
        print("Tex:",hexList[0x00:0x0c])
        self.global_Offset      = None
        self.flag0              = hexList[0x00:0x01] #np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x00:0x01], keepSpaces=False)),np.uint8)
        self.textureIndex       = hexList[0x01:0x02] #np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x01:0x02], keepSpaces=False)),np.uint8)
        self.adressMode_uv      = hexList[0x02:0x03] #np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x02:0x03], keepSpaces=False)),np.uint8)
        self.filtering_minMag   = hexList[0x03:0x04] #np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x03:0x04], keepSpaces=False)),np.uint8)
        self.texture_scale_u    = hexList[0x04:0x08] #np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x04:0x08], keepSpaces=False)),np.float32)
        self.texture_scale_v    = hexList[0x08:0x0c] #np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x08:0x0c], keepSpaces=False)),np.float32)
    pass

class EMDTriangles_Section:
    def __init__(self,hexList):
        print("Tri:",hexList[0x00:0x0c])
        self.global_Offset      = None
        self.number_faces       = int(np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x00:0x04], keepSpaces=False)),np.uint32)[0]/3)
        self.number_bones       = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x04:0x08], keepSpaces=False)),np.uint32)[0]
        self.offset_faces       = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x08:0x0c], keepSpaces=False)),np.uint32)[0]
        self.offset_bone_names  = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x0c:0x10], keepSpaces=False)),np.uint32)[0]
        #print(self.number_faces)
        #print(self.offset_faces)
        pointers = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[self.offset_bone_names:self.offset_bone_names+ (4 * self.number_bones)],keepSpaces=False)), np.uint32)
        self.bone_names = [self.get_name(hexList,point) for point in pointers]
        #print(self.bone_names)
        self.Faces = [np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[self.offset_faces:][curFace * 6:(curFace * 6) + 6], keepSpaces=False)),np.uint16) for curFace in range(0, self.number_faces)]


    def get_name(self,hList,NameOffset):
        decodeThis = ''
        if '00' in hList[NameOffset:]:
            for hexItem in hList[NameOffset:NameOffset+hList[NameOffset:].index('00')]:
                decodeThis += hexItem
        else:
            for hexItem in hList[NameOffset:]:
                decodeThis += hexItem
        return str(bytes.fromhex(decodeThis).decode('charmap'))
    pass




class Face:
    def __init__(self,HEXLEN6):
        self.vertIndicies = np.frombuffer(bytes.fromhex(hexList2hexStrList(HEXLEN6, keepSpaces=False)),np.uint16)
        pass


class FaceCloud:
    def __init__(self):
        self.cloud = []
        self.offset = 0
        self.padding = 0
        pass
class VertexCloud:
    def __init__(self):
        self.cloud = []
        self.offset = 0
        self.padding = 24
        pass
