from EMDFileObj import *

fileName = "C:/Users/Christopher Tully/Desktop/" \
           "Dragon Ball Game Editor/chara/GOK/GOK_002_Bust.emd"

byteList = open(fileName,"rb").read()

def Reader(fileBytes):
    emdfileHex = hexify(fileBytes)
    hexList = emdfileHex.split(' ')
    EMDData = EMD(hexList)
    
    print("Header:")
    print("\tHeader Size:\t",   EMDData.Header.header_size)
    print("\tSignature:\t\t",   EMDData.Header.signature)
    print("\tUnknown 0:\t\t",   EMDData.Header.unknow_0)
    print("\tEndian:\t\t\t",    EMDData.Header.endian)
    print("\tVersion:\t\t",     EMDData.Header.version)
    print()
    
    print("EMD Section:")
    print("\tUnknown 0:\t\t\t",         EMDData.Section.unknow_0)
    print("\tModel Count:\t\t",         EMDData.Section.number_models)
    print("\tModel Offsets:\t\t",       EMDData.Section.offset_models)
    print("\tModel Name Offsets:\t",    EMDData.Section.offset_models_name)
    print("\tName Pointers:\t\t",       EMDData.Section.name_pointers)
    print("\tModel Names:\t\t",         EMDData.Section.mod_names)
    print("\tModel Pointers:\t\t",      EMDData.Section.mod_pointers)
    print()
    
    print("Models:")
    for item in EMDData.Models:
        
        print("\tModel:",           item.name)
        #print("\t\tGlobal Offset:\t",  item.global_Offset)
        print("\t\tUnknown 0:\t\t",      item.unknow_0)
        print("\t\tMesh Count:\t\t",     item.number_meshs)
        print("\t\tMesh Offset:\t",    item.offset_meshs)
        print("\t\tMesh Pointers:\t",  item.mes_pointers)
        #print("\t\tMesh Hex:",       item.meshHexes)
        print("\t\tMeshes:\t\t\t",         item.meshes)
    print()
    
    #print(EMDData.Meshes)
    #print()
    
    print("Submeshes:")
    for ite in EMDData.SubMeshes:
        for it in ite:
            for i in it:
                print(i.number_textureDef)
                print(i.tex_pointers)
    print()
    
    
    #print(EMDData.Vertices)
    #print()
    
    print("TextureDefs")
    for ite in EMDData.TextureDefs:
        for it in ite:
            if it.flag0:#.size > 0:
                print("Global Offset:", it.global_Offset)
                print("flag0:", it.flag0)
                print("Texture Index:", it.textureIndex)
                print("Address Mode UV:", it.adressMode_uv)
                print("Filtering Min Mag:", it.filtering_minMag)
                print("Texture Scale U:", it.texture_scale_u)
                print("Texture Scale V:", it.texture_scale_v)
                print()
    print()

    # print(EMDData.Triangles)
    # print()
    
    
Reader(byteList)
