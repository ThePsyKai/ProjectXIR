#DXT1: RGB, 4bits per pixel, no alpha or 1bit (black or white) alpha.
#   fixed 8:1 compression
#DXT3: ARGB, 8bits per pixel, explicit alpha.
#   fixed 4:1 compression
#DXT5: ARGB, 8bits per pixel, interpolated alpha.
#   fixed 4:1 compression
from typing import List
from itertools import permutations
import numpy as np
from fileUtil import *
import struct
import bpy

def float32_to_hex(input_int: float or List[float]):
    hex_item = hex(struct.unpack('<I', struct.pack('<f', input_int))[0])
    final_hex = [hex_item[2:][0:2], hex_item[2:][2:4], hex_item[2:][4:6], hex_item[2:][6:8]]
    for item in range(0, len(final_hex)):
        if final_hex[item] == '':
            final_hex[item] = '00'
        if 2 - len(final_hex[item]):
            final_hex[item] = '0' + final_hex[item]
    if not np.frombuffer(bytes.fromhex(hexList2hexStrList(final_hex, keepSpaces=False)), np.float32)[0] == input_int:
        option_list = list(permutations(final_hex))
        for ind in option_list:
            final_hex = list(ind)
            if np.frombuffer(bytes.fromhex(hexList2hexStrList(final_hex, keepSpaces=False)), np.float32)[0] == input_int:
                break
    return final_hex

def uint8_to_hex(input_int: int or List[int]):
    hex_item = hex(struct.unpack('<I', struct.pack('<l', input_int))[0])
    final_hex = hex_item[2:][0:2]
    if 2-len(final_hex):
        final_hex = '0'+final_hex
    return final_hex

def uint16_to_hex(input_int: int or List[int]):
    hex_item = hex(struct.unpack('<I', struct.pack('<l', input_int))[0])
    hex_item = '0' * (4 - len(hex_item[2:])) + hex_item[2:]
    final_hex = [hex_item[0:2], hex_item[2:4]]
    potential        = [list(ite) for ite in list(permutations(final_hex))]
    potential_vals = [np.frombuffer(bytes.fromhex(hexList2hexStrList(list(ite), keepSpaces=False, endian=False)), np.uint16)[0] for ite in potential]
    if input_int in potential_vals:
        final_hex = potential[potential_vals.index(input_int)]
    return final_hex

def uint32_to_hex(input_int: int or List[int]):
    hex_item = hex(struct.unpack('<I', struct.pack('<l', input_int))[0])
    hex_item = '0'*(8-len(hex_item[2:]))+hex_item[2:]
    final_hex = hexList2hexStrList([hex_item[0:2],hex_item[2:4],hex_item[4:6],hex_item[6:8]], keepSpaces=True, endian=True)
    final_hex = final_hex.split(' ')[:-1]
    return final_hex


class DDS:
    def __init__(self,hexList):
        print(hexList[0:128])
        print(hex(0x2f+2))
        print(hexList[0x20:0x40])
        self.signature              = hex2str(hexList[0x00:0x04])
        self.header_size            = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x04:0x08],keepSpaces=False)),np.uint32)[0]
        self.flags                  = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x08:0x0c],keepSpaces=False)),np.uint32)[0]#hexList[8:12]
        self.height                 = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x0c:0x10],keepSpaces=False)),np.uint32)[0]#hexList[12:16]
        self.width                  = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x10:0x14],keepSpaces=False)),np.uint32)[0]#hexList[16:20]
        self.Texture0_byte_count    = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x14:0x18],keepSpaces=False)),np.uint32)[0]#hexList[20:24]
        self.depth                  = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x18:0x1c],keepSpaces=False)),np.uint32)[0]#hexList[24:28]
        self.mipmap_count           = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x1c:0x20],keepSpaces=False)),np.uint32)[0]#hexList[28:32]

        self.unknown_1              = hexList[0x20:0x2b]

        self.PixelFormat            = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x2b:0x2f],keepSpaces=False)),np.uint32)[0]
        self.DDSCaps                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hexList[0x2f:0x31],keepSpaces=False)),np.uint16)[0]

        self.unknown_2              = hexList[0x31:0x40+12]

        ###ddpfPixelFormat
        PFhexList = hexList[0x40+12:]
        print(PFhexList)

        self.PFHeaderSize           = np.frombuffer(bytes.fromhex(hexList2hexStrList(PFhexList[0x00:0x04],keepSpaces=False)),np.uint32)[0]
        self.PFFlags                = np.frombuffer(bytes.fromhex(hexList2hexStrList(PFhexList[0x04:0x08],keepSpaces=False)),np.uint32)[0]
        self.FourCC                 = hex2str(PFhexList[0x08:0x0c])
        self.RGBBitCount            = np.frombuffer(bytes.fromhex(hexList2hexStrList(PFhexList[0x0c:0x10],keepSpaces=False)),np.uint32)[0]
        self.RBitMask               = np.frombuffer(bytes.fromhex(hexList2hexStrList(PFhexList[0x10:0x14],keepSpaces=False)),np.uint32)[0]
        self.GBitMask               = np.frombuffer(bytes.fromhex(hexList2hexStrList(PFhexList[0x14:0x18],keepSpaces=False)),np.uint32)[0]
        self.BBitMask               = np.frombuffer(bytes.fromhex(hexList2hexStrList(PFhexList[0x18:0x1c],keepSpaces=False)),np.uint32)[0]
        self.RGBAlphaBitMask        = np.frombuffer(bytes.fromhex(hexList2hexStrList(PFhexList[0x1c:0x20],keepSpaces=False)),np.uint32)[0]

        ###dwCaps
        CAhexList = PFhexList[0x20:]

        self.Caps1                  = np.frombuffer(bytes.fromhex(hexList2hexStrList(CAhexList[0x00:0x04],keepSpaces=False)),np.uint32)[0]
        self.Caps2                  = np.frombuffer(bytes.fromhex(hexList2hexStrList(CAhexList[0x04:0x08],keepSpaces=False)),np.uint32)[0]
        self.unknown_3              = CAhexList[0x08:0x0a]

    def get_flags(self):
        theFlags = '0'*(24-len(bin(self.flags)[2:]))+bin(self.flags)[2:]
        DDSD_CAPS           = int(theFlags[-1])
        DDSD_HEIGHT         = int(theFlags[-2])
        DDSD_WIDTH          = int(theFlags[-3])
        DDSD_PITCH          = int(theFlags[-8])
        DDSD_PIXELFORMAT    = int(theFlags[-13])
        DDSD_MIPMAPCOUNT    = int(theFlags[-18])
        DDSD_LINEARSIZE     = int(theFlags[-20])
        DDSD_DEPTH          = int(theFlags[-24])

        return [['DDSD_CAPS',
                 'DDSD_HEIGHT',
                 'DDSD_WIDTH',
                 'DDSD_PITCH',
                 'DDSD_PIXELFORMAT',
                 'DDSD_MIPMAPCOUNT',
                 'DDSD_LINEARSIZE',
                 'DDSD_DEPTH'],
                [DDSD_CAPS,
                 DDSD_HEIGHT,
                 DDSD_WIDTH,
                 DDSD_PITCH,
                 DDSD_PIXELFORMAT,
                 DDSD_MIPMAPCOUNT,
                 DDSD_LINEARSIZE,
                 DDSD_DEPTH]]

    def get_PFFlags(self):
        theFlags = '0'*(7-len(bin(self.PFFlags)[2:]))+bin(self.PFFlags)[2:]
        DDPF_ALPHAPIXELS        = int(theFlags[-1])
        DDPF_FOURCC             = int(theFlags[-3])
        DDPF_RGB                = int(theFlags[-7])
        return [['DDPF_ALPHAPIXELS',
                 'DDPF_FOURCC',
                 'DDPF_RGB'],
                [DDPF_ALPHAPIXELS,
                 DDPF_FOURCC,
                 DDPF_RGB]]

    def get_CA1Flags(self):
        theFlags = '0' * (23 - len(bin(self.Caps1)[2:])) + bin(self.Caps1)[2:]
        DDSCAPS_COMPLEX     = int(theFlags[ -4])
        DDSCAPS_TEXTURE     = int(theFlags[-13])
        DDSCAPS_MIPMAP      = int(theFlags[-23])
        return [['DDSCAPS_COMPLEX',
                 'DDSCAPS_TEXTURE',
                 'DDSCAPS_MIPMAP'],
                [DDSCAPS_COMPLEX,
                 DDSCAPS_TEXTURE,
                 DDSCAPS_MIPMAP]]

    def get_CA2Flags(self):
        theFlags = '0' * (22 - len(bin(self.Caps1)[2:])) + bin(self.Caps1)[2:]
        DDSCAPS2_CUBEMAP            = int(theFlags[-10])
        DDSCAPS2_CUBEMAP_POSITIVEX  = int(theFlags[-11])
        DDSCAPS2_CUBEMAP_NEGATIVEX  = int(theFlags[-12])
        DDSCAPS2_CUBEMAP_POSITIVEY  = int(theFlags[-13])
        DDSCAPS2_CUBEMAP_NEGATIVEY  = int(theFlags[-14])
        DDSCAPS2_CUBEMAP_POSITIVEZ  = int(theFlags[-15])
        DDSCAPS2_CUBEMAP_NEGATIVEZ  = int(theFlags[-16])
        DDSCAPS2_VOLUME             = int(theFlags[-22])




        return [['DDSCAPS2_CUBEMAP',
                 'DDSCAPS2_CUBEMAP_POSITIVEX',
                 'DDSCAPS2_CUBEMAP_NEGATIVEX',
                 'DDSCAPS2_CUBEMAP_POSITIVEY',
                 'DDSCAPS2_CUBEMAP_NEGATIVEY',
                 'DDSCAPS2_CUBEMAP_POSITIVEZ',
                 'DDSCAPS2_CUBEMAP_NEGATIVEZ',
                 'DDSCAPS2_VOLUME'],
                [DDSCAPS2_CUBEMAP,
                 DDSCAPS2_CUBEMAP_POSITIVEX,
                 DDSCAPS2_CUBEMAP_NEGATIVEX,
                 DDSCAPS2_CUBEMAP_POSITIVEY,
                 DDSCAPS2_CUBEMAP_NEGATIVEY,
                 DDSCAPS2_CUBEMAP_POSITIVEZ,
                 DDSCAPS2_CUBEMAP_NEGATIVEZ,
                 DDSCAPS2_VOLUME]]
#DATA000.dds

#def option():
#    with open("C:/Users/Christopher Tully/Desktop/DATA000.dds",'rb') as img:
#        fileHex = hexify(img.read()).split(' ')
#        newDDS = DDS(fileHex)
#        print('signature:\t\t\t\t',newDDS.signature)
#        print('header_size:\t\t\t',newDDS.header_size)
#        print('flags:\t\t\t\t\t', bin(newDDS.flags)[2:])
#        print('height:\t\t\t\t\t',newDDS.height)
#        print('width:\t\t\t\t\t',newDDS.width)
#        print('Texture0_byte_count:\t',newDDS.Texture0_byte_count)
#        print('depth:\t\t\t\t\t',newDDS.depth)
#        print('mipmap_count:\t\t\t',newDDS.mipmap_count)
#        print(newDDS.unknown_1)
#        print('PixelFormat:\t\t\t',newDDS.PixelFormat)
#        print('DDSCaps:\t\t\t\t',newDDS.DDSCaps)
#        print(newDDS.unknown_2)
#        print()
#        print('PFHeader:\t\t\t\t', newDDS.PFHeaderSize)
#        print('PFFlags:\t\t\t\t', bin(newDDS.PFFlags)[2:])
#        print('FourCC:\t\t\t\t\t', newDDS.FourCC)
#        print('RGBBitCount:\t\t\t',newDDS.RGBBitCount)
#        print('RBitMask:\t\t\t\t',newDDS.RBitMask)
#        print('GBitMask:\t\t\t\t',newDDS.GBitMask)
#        print('BBitMask:\t\t\t\t',newDDS.BBitMask)
#        print('RGBAlphaBitMask:\t\t',newDDS.RGBAlphaBitMask)
#        print()
#        print(newDDS.Caps1)
#        print(newDDS.Caps2)
#        print(newDDS.unknown_3)
#
#
#        print()
#        print('SD Flags:')
#        for it in range(0,len(newDDS.get_flags()[0])):
#            print('\t'+newDDS.get_flags()[0][it],newDDS.get_flags()[1][it])
#        #print(hex2str(hexList2hexStrList(fileHex,False)))
#        print()
#        print('PF Flags:')
#        for it in range(0, len(newDDS.get_PFFlags()[0])):
#            print('\t' + newDDS.get_PFFlags()[0][it], newDDS.get_PFFlags()[1][it])
#        print()
#        print('CA1 Flags:')
#        for it in range(0, len(newDDS.get_CA1Flags()[0])):
#            print('\t' + newDDS.get_CA1Flags()[0][it], newDDS.get_CA1Flags()[1][it])
#        print()
#        print('CA2 Flags:')
#        for it in range(0, len(newDDS.get_CA2Flags()[0])):
#            print('\t' + newDDS.get_CA2Flags()[0][it], newDDS.get_CA2Flags()[1][it])
#
#    img.close()
#def list_directory(file_path, file_filter=None):
#    for test_file in [item for item in os.listdir(file_path)]:
#        if os.path.isdir(file_path + '/' + test_file):
#            list_directory(file_path + '/' + test_file, file_filter=file_filter)
#        elif os.path.isfile(file_path + '/' + test_file):
#            if '.dds' in test_file and '.xml' not in test_file:
#                with open(file_path + '/' + test_file, 'rb') as img2:
#                    fileHex = hexify(img2.read()).split(' ')
#                    #print(fileHex)
#                    newDDS = DDS(fileHex)
#                    #try:
#                    #    if not bin(newDDS.flags)[2:][-4]:
#                    print(file_path, test_file)
#                    #print('signature:\t\t\t\t', newDDS.signature)
#                    #print('header_size:\t\t\t', newDDS.header_size)
#                    #print('flags:\t\t\t\t\t', '0'*(20-len(bin(newDDS.flags)[2:]))+bin(newDDS.flags)[2:])
#                    #print('height:\t\t\t\t\t', newDDS.height)
#                    #print('width:\t\t\t\t\t', newDDS.width)
#                    #print('Texture0_byte_count:\t', newDDS.Texture0_byte_count)
#                    #print('depth:\t\t\t\t\t', newDDS.depth)
#                    #print('mipmap_count:\t\t\t', newDDS.mipmap_count)
#                    print(newDDS.unknown_1)
#                    print('DXTFormat:\t\t\t\t', newDDS.DXTFormat)
#                    #except:
#                    #    print(file_path, test_file)
#
#test_image_list = []
#for image in ['C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK/GOK_000_Boots.dyt/DATA000.dds',
#              'C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK/GOK_000_Boots.dyt/DATA001.dds',
#              'C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK/GOK_000_Boots.dyt/DATA002.dds',
#              'C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK/GOK_000_Boots.dyt/DATA003.dds',
#              'C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK/GOK_000_Boots.dyt/DATA004.dds',
#              'C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK/GOK_000_Boots.dyt/DATA005.dds',
#              'C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK/GOK_000_Boots.dyt/DATA006.dds',
#              'C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK/GOK_000_Boots.dyt/DATA007.dds',
#              'C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK/GOK_000_Boots.dyt/DATA008.dds',
#              ]:
#    with open(image, 'rb') as img:
#        test_image_list.append(img.read())

def Gather_DDS() -> List[bytes]:

    pass

def Write_EMB(EMBName, DDSImages:List[bytes], DYT:bool=False):
    if DYT:
        EMBName += '.dyt'
    hex_out_list = []
    signature = str2hex('#EMB').split(' ')
    endian = uint16_to_hex(65534)
    header_size = uint16_to_hex(32)
    version = [uint8_to_hex(item) for item in [132, 146, 0, 0]]
    image_count = uint32_to_hex(len(DDSImages))
    unknow_0 = [uint8_to_hex(item) for item in [0, 0, 0, 0]]
    unknow_1 = [uint8_to_hex(item) for item in [0, 0, 0, 0]]
    unknow_2 = uint32_to_hex(32)
    unknow_3 = [uint8_to_hex(item) for item in [0, 0, 0, 0]]

    image_offsets = []
    for item in range(0,len(DDSImages)):
        if len(image_offsets):
            image_offsets.append(32+(8*len(DDSImages))+(len(DDSImages[item])*item))
        else:
            image_offsets.append(32 + (8 * len(DDSImages)))
        image_offsets.append(len(DDSImages[item]))
    for item in range(0,len(image_offsets),2):
        image_offsets[item] -= int(((item/2)*8)+8)
        pass
    offsets = []
    for it in [uint32_to_hex(ite) for ite in image_offsets]:
        offsets.extend(it)

    temp = image_offsets[0]+32
    image_offsets = offsets
    hex_out_list.extend(signature)
    hex_out_list.extend(endian)
    hex_out_list.extend(header_size)
    hex_out_list.extend(version)
    hex_out_list.extend(image_count)
    hex_out_list.extend(unknow_0)
    hex_out_list.extend(unknow_1)
    hex_out_list.extend(unknow_2)
    hex_out_list.extend(unknow_3)
    hex_out_list.extend(image_offsets)

    hex_out_list.extend(['00']*(temp-len(hex_out_list)))
    for DDS_item in DDSImages:
        hex_out_list.extend(hexify(DDS_item).split(' '))
    with open('C:/Users/Christopher Tully/Desktop/'+EMBName+'.emb', 'wb') as emb:
        emb.write(bytes.fromhex(hexList2hexStrList(hex_out_list,False)))
    emb.close()








Write_EMB('Hell',test_image_list)

#oof1 = hexify(open('C:/Users/Christopher Tully/Desktop/Hell.emb', 'rb').read()).split(' ')
#
#oof2 = hexify(open('C:/Users/Christopher Tully/Desktop/GOK_000_Boots.dyt.emb', 'rb').read()).split(' ')
#
#if oof1 != oof2:
#    test_list = []
#    for item1 in range(0, len(oof2)):
#        if oof1[item1] == oof2[item1]:
#            print(oof1[item1], end=' ')
#            test_list.append(oof1[item1])
#        else:
#            print()
#            print(oof1[item1:item1 + 50])
#            print(oof2[item1:].index('44') + 8, item1 - 8)
#            break
#    print(test_list[:32])
#print(len(oof1),len(oof2))
