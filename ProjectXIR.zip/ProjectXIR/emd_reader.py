from .fileUtil import (str2hex,hex2str,hexify,fileReader,hexList2hexStrList,)
import re
from .handlingHex import vertHex2Float,hex_to_float,hexToHalfFloat,hexToShort,hex2float
from .emd_file_obj import *
import time

from .esk_reader import get_bone_names


class global_Values:
    properFaceCount = 0
    boneKeys = ['_R_', '_C_', '_L_', 'SCD_']
    invalid = ['', ' ', '']
    valid = '0123456789abcdef'


#/*-------------------------------------------------------------------------------\#
#|                         Generate Edge Data for Blender                         |#
#\-------------------------------------------------------------------------------*/#
def facesToEdges(faceList):
    edgeList = []
    for i in faceList:
        edgeList.append(tuple((i[0],i[1])))
        edgeList.append(tuple((i[0],i[2])))
        edgeList.append(tuple((i[1],i[2])))
    return edgeList

#/*--------------------------------------------------------------------------------\#
#|          Get Lines Containing Vertex XYZ, UVCoordinates, Normal Values          |#
#\--------------------------------------------------------------------------------*/#
def vertexLines(HEX: str, off: int, count: int) -> list:
    htemp = HEX.split(' ')
    vLTemp = []
    vTemp = []
    for i in htemp[off:off+(count*36)]:
        vTemp.append(i)
        if len(vTemp) == 36:
            vLTemp.append(vTemp)
            vTemp = []
    return vLTemp

#/*-------------------------------------------------------------------------------\#
#|                   Get Vertex Count (Largest Face Data Value)                   |#
#\-------------------------------------------------------------------------------*/#
def get_vertex_count(FaceHex: str, off: int, count: int,off2: int=None,count2: int=None):
    tList = FaceHex[off:].split(' ')
    tList = tList[:int(count) * 6]
    ttList = []
    for i in range(1,len(tList),2):
        ttList.append(tList[i-1:i+1])
    for item in ttList:
        ttList[ttList.index(item)] = int(item[1]+item[0] ,16)+1
    if off2 is not None and count2 is not None:
        tList = FaceHex[off2:].split(' ')
        tList = tList[:int(count2) * 6]
        ttList2 = []
        for i in range(1, len(tList), 2):
            ttList2.append(tList[i - 1:i + 1])
        for item in ttList2:
            ttList2[ttList2.index(item)] = int(item[1] + item[0], 16) + 1
        ttList.extend(ttList2)
    ttList.sort()
    tNum = 0
    for k in ttList:
        if ttList.index(k)+1 < len(ttList):
            if ttList[ttList.index(k)+1]-k == 1 or ttList[ttList.index(k)+1]-k == 0:
                pass
            elif ttList[ttList.index(k)+1]-k > 1:
                tNum = ttList.index(k)
                break
    if tNum == 0:
        pass
    else:
        ttList = ttList[:tNum]
    return ttList[-1]

#/*-------------------------------------------------------------------------------\#
#|                           Check If Face Hex Is Valid                           |#
#\-------------------------------------------------------------------------------*/#
def isFace(HEXLEN6: list, returnFace: bool=None):
    valid = ['00', '01', '02','03','04','05','06','07', '08','09','0a','0b','0c','0d','0e','0f']
    tempFace = []
    for i in range(1,len(HEXLEN6),2):
        if HEXLEN6[i] in valid:
            tempFace.append(int(HEXLEN6[i] + HEXLEN6[i-1],16))
            pass
        else:
            return False
    if tempFace.count(tempFace[0]) > 1 or tempFace.count(tempFace[1]) > 1:
        return False
    if returnFace is not None:
        return tempFace
    return True

#/*-------------------------------------------------------------------------------\#
#|                              Get Face Data Offset                              |#
#\-------------------------------------------------------------------------------*/#
def get_face_offset(HEX):
    returnList = []
    filterLength = 63
    FOUND = [int((m.start()+filterLength)/3) for m in re.finditer("22 \w\w \w\w 80 3f \w\w \w\w 80 3f \w\w \w\w \w\w 22 \w\w \w\w 80 3f \w\w \w\w 80 3f ",HEX)]
    for off in FOUND:
        tList = HEX.split(' ')[off + 20:]
        for number in range(0,len(tList),4):
            if tList[number:number + 4][2:4] == ['00','00'] and tList[number:number + 4][0:2] != ['00','00']:
                    if isFace(tList[number:number + 6]) and isFace(tList[number + 6:number + 12]):
                        returnList.append((off + 20 + number) * 3)
                        break
                    pass
            else:
                returnList.append((off + 20 + number)*3)
                break
    return [FOUND,returnList]

#/*-------------------------------------------------------------------------------\#
#|                                 Get Face Count                                 |#
#\-------------------------------------------------------------------------------*/#
def get_face_count(HEX: str, OFFSET):
    tList = HEX[OFFSET:].split(' ')
    tVal = 0
    vertexCount = 0
    diamondCheck = []
    priorFace = []
    for i in range(1,len(tList),2):
        if len(priorFace) < 3:
            priorFace.append(int(str(tList[i]) + str(tList[i - 1]), 16) + 1)
        else:
            diamondCheck.append(priorFace)
            priorFace = [int(str(tList[i]) + str(tList[i - 1]), 16) + 1]
        if tList[i] == '00' or tList[i] == '01' or tList[i] == '02' or tList[i] == '03' or tList[i] == '04' or tList[i] == '05' or tList[i] == '06' or tList[i] == '07' or tList[i] == '08' or tList[i] == '09':
            if int(str(tList[i])+str(tList[i-1]),16)+1 >= vertexCount:
                vertexCount = int(str(tList[i])+str(tList[i-1]),16)+1
            pass
        elif (tList[i] == '0a' or tList[i] == '0b' or tList[i] == '0c' or tList[i] == '0d' or tList[i] == '0e' or tList[i] == '0f') and tList[i+1:i+2] != ["00", "00"]:
            pass
        else:
            tVal = i
            break
    diamond = []
    for x in range(len(diamondCheck)-1,0,-1):
        if diamondCheck[x][1] == 1:
            diamond.append(diamondCheck[x])
        elif diamondCheck[x][0] == 1 and diamondCheck[x][2] == 1:
            diamond.append(diamondCheck[x])
        else:
            break
    return int(tVal/6) - len(diamond)

#/*-------------------------------------------------------------------------------\#
#|                    GetFace Data Given Offset And Face Count                    |#
#\-------------------------------------------------------------------------------*/#
def faceData(HEX: str, off: int, count, off2: int=None, count2: int=None):
    tList = HEX.split(' ')[int(off/3):int(off/3) + (count * 6)]
    returnList = []
    tL = []
    for i in range(0,len(tList),2):
        tL.append(int(tList[i+1]+tList[i],16))
        if len(tL) == 3:
            returnList.append(tuple(tL))
            tL = []
    if off2 is not None and count2 is not None:
        print('Accounting for Split')
        tList = HEX.split(' ')[int(off2 / 3):int(off2 / 3) + (count2 * 6)]
        returnList2 = []
        tL = []
        for i in range(0, len(tList), 2):
            tL.append(int(tList[i + 1] + tList[i], 16))
            if len(tL) == 3:
                returnList2.append(tuple(tL))
                tL = []
        returnList.extend(returnList2)
        return returnList
    return returnList



#/*-------------------------------------------------------------------------------\#
#|                        Verify If The Offset Is Accurate                        |#
#\-------------------------------------------------------------------------------*/#
def verify_vertex_offset(HEX, OFF: int):
    #print("Offset: ", OFF)
    if type(HEX) == str:
        tempHex = HEX.split(' ')
    elif type(HEX) == list:
        tempHex = HEX
    tempOff = int(OFF/3)
    vertXYZHex = tempHex[tempOff:tempOff+12]
    checkList = [hex_to_float(vertXYZHex[0:4]),hex_to_float(vertXYZHex[4:8]),hex_to_float(vertXYZHex[8:12])]
    if 'e' in str(checkList[0]) or 'e' in str(checkList[1]) or 'e' in str(checkList[2]):
        print("Found 'e' in Number")
        return False
    elif abs(checkList[0]) > 10000 or abs(checkList[1]) > 10000 or abs(checkList[2]) > 10000:
        print("Greater than 10000")
        return False
    else:
        return True

#/*------------------------------------------------------------------------------\#
#|                            Get Vertex Cloud Offset                            |#
#\------------------------------------------------------------------------------*/#
def get_vertex_offset(HEXSTR: str, FACEOFF: int, FACECOUNT: int):
    temp = splitBypass(HEXSTR.split(' '),FACEOFF,FACECOUNT)
    distLastWord2Off = (HEXSTR[:temp[1]*3].rindex(temp[2])+len(temp[2]))
    dist = temp[1] - int(distLastWord2Off/3)
    if dist > 4:
        tempOff = 0
        tempOff += int(distLastWord2Off/3)+1
        for k in range(0,dist):
            if verify_vertex_offset(HEXSTR, (tempOff + k)*3):
                return (tempOff+k)*3
                pass
        return temp[1]*3
    else:
        return temp[1]*3


#/*-------------------------------------------------------------------------------\#
#|                   Get Around Face Data Split By Bone Cluster                   |#
#\-------------------------------------------------------------------------------*/#
def splitBypass(HEX:list,off:int,count:int):
    tList = HEX[off + (count * 6):]
    tVal = 0
    # Find the location of bone cluster
    # -------------------------------- #
    secondHalf = False
    if tList[0:4][2:4] == ['00', '00'] and tList[0:4][0:2] != ['00', '00']:
        secondHalf = True
    elif tList[0:4][0:2] == ['00', '00'] and tList[0:4][2:4] != ['00', '00']:
        secondHalf = False
    for i in range(0, len(tList), 4):
        if secondHalf:
            tempSTR = [hex2str(x) for x in tList[i:i + 4]]
            if (tList[i:i + 4][2:4] == ['00', '00'] and tList[i:i + 4][0:2] != ['00', '00']) or (tempSTR[2] in global_Values.invalid and tList[3] == '00'):
                pass
            else:
                tVal = i
                if tList[tVal:][0] == '00':
                    tVal+=1
                break
        else:
            if tList[i:i + 4][0:2] == ['00', '00'] and tList[i:i + 4][2:4] != ['00', '00']:
                pass
            else:
                tVal = i - 2
                break
    # -------------------------------- #
    tList = tList[tVal:]
    tempWords = []
    word = ''
    for i in range(0, len(tList)):
        if tList[i] != '00':
            word += tList[i] + ' '
            pass
        else:
            if i+1 < len(tList):
                if tList[i + 1] != '00':
                    for item in global_Values.boneKeys:
                        if str2hex(item) in word:
                            tempWords.append(word)
                            word = ''
                    pass
                else:
                    for item in global_Values.boneKeys:
                        if str2hex(item) in word:
                            tempWords.append(word)
                    strHex = hexList2hexStrList(HEX[:(off + (count * 6) + i + tVal)])
                    add = strHex.rindex(tempWords[-1]) + len(tempWords[-1])
                    tList = HEX[int(add / 3):]
                    while True:
                        if tList[0] == '00':
                            add+=3
                            tList = tList[1:]
                        else:
                            break
                    return [tList,int(add/3),tempWords[-1]]
    pass

#/*-------------------------------------------------------------------------------\#
#|                    Check If End Of Face Data Is A Split       		          |#
#\-------------------------------------------------------------------------------*/#
def is_Split(HEX: list, off:int, count: int) -> bool:
    temp2 = splitBypass(HEX, off, count)
    ttList = temp2[0]
    string = "1234567890abcdefghijklmnopqrstuvwxyz"
    for i in string:
        for k in string:
            if i+k != '00':
                if ("00 00 00 %s%s 00 00 00" % (i,k)) in hexList2hexStrList(ttList[:18]):
                    for l in range(0, len(ttList), 4):
                        if ttList[l:l + 4][2:4] == ['00', '00']:
                            pass
                        else:
                            break
                    return True
                else:
                    pass
    return False
    pass

#/*-------------------------------------------------------------------------------\#
#|                    Grab Face Offset/Count of Second Half        		          |#
#\-------------------------------------------------------------------------------*/#
def goAroundSplit(HEX: list, off: int, count: int):
    temp2 = splitBypass(HEX,off,count)
    ttList = temp2[0]
    if ttList[0] == '00' and ttList[1] == '00':
        ttList = ttList[2:]
    tVal = 0
    for i in range(0,len(ttList),4):
        if ttList[i:i+4][2:4] == ['00','00']:
            pass
        else:
            tVal = i
            break
    altFaceOffset = temp2[1]+tVal
    ttList = HEX[altFaceOffset:]
    if isFace(ttList[:6]):
        pass
    else:
        altFaceOffset+=1
    ttList = HEX[altFaceOffset:]
    altFaceCount = get_face_count(hexList2hexStrList(ttList), 0)
    return [altFaceOffset,altFaceCount]

#/*-------------------------------------------------------------------------------\#
#|              Locate Potential Words Found In charmap Decoded File              |#
#\-------------------------------------------------------------------------------*/#
def englishFilter(HEX):
    validEnglish = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890_'
    if type(HEX) == str:
        hSplit = HEX.split(' ')
    elif type(HEX) == list:
        hSplit = HEX
    tList = []
    tStr = ''
    for x in range(0,len(hSplit)):
        if validEnglish.__contains__(hex2str(hSplit[x])):
            tStr+=hex2str(hSplit[x])
        else:
            if tStr != '' and len(tStr) > 1:
                tList.append(tStr)
                tStr = ''
            else:
                tStr = ''
    return tList

#/*------------------------------------------------------------------------------\#
#|                            Get Names For SubMeshes                            |#
#\------------------------------------------------------------------------------*/#
def get_mesh_names(HEX: str,OFFList: list):
    returnList = [englishFilter(HEX.split(' ')[:i - 21])[-1] for i in OFFList]
    return returnList

#/*--------------------------------------------------------------------------------\#
#|                       Get Vertex XYZ Hex From Vertex Line                       |#
#\--------------------------------------------------------------------------------*/#
def getVertexXYZ(vL):
    vertices = [[vert[0:4], vert[4:8], vert[8:12]] for vert in vL]
    return vertices

def get_uv(vL):
    UVList = [[line[20:22],line[22:24]] for line in vL]
    return UVList

def get_normals(vL):
    norms = [[norm[12:14], norm[14:16], norm[16:18]] for norm in vL]
    return norms

def which_bone_cluster(current_vertex: Vertex,VGNames:list):
    try:
        current_vertex.vertex_groups[0][0] = VGNames[list(current_vertex.vertex_groups)[0][0]]
    except TypeError:
        pass

    try:
        if len(list(current_vertex.vertex_groups)) > 1:
            current_vertex.vertex_groups[1][0] = VGNames[list(current_vertex.vertex_groups)[1][0]]
        else:
            Group2 = None
    except TypeError:
        pass

    try:
        if len(list(current_vertex.vertex_groups)) > 2:
            current_vertex.vertex_groups[2][0] = VGNames[list(current_vertex.vertex_groups)[2][0]]
        else:
            Group3 = None
    except TypeError:
        pass

    try:
        if len(list(current_vertex.vertex_groups)) > 3:
            current_vertex.vertex_groups[3][0] = VGNames[list(current_vertex.vertex_groups)[3][0]]
        else:
            Group4 = None
    except TypeError:
        pass


    #print([item2[0] for item2 in current_vertex.vertex_groups if item2[0] is not None])
    pass


def get_vertex_weights(line:list, curVert, VGNames: list, VGNames2: list =None):

    checkLineVGIndex = line[24:34]
    print(int(checkLineVGIndex[0], 16),int(checkLineVGIndex[1], 16),int(checkLineVGIndex[2], 16),int(checkLineVGIndex[3], 16))
    Group1,Group2,Group3,Group4 = None,None,None,None

    if VGNames2 is not None:
        x = curVert.location[0]
        try:
            VGGroup1 = VGNames2[int(checkLineVGIndex[0], 16)]
            VGGroup2 = VGNames[int(checkLineVGIndex[0], 16)]
            if x > 0:
                if '_C_' in VGGroup1:
                    Group1 = VGGroup1
                elif '_C_' in VGGroup2:
                    Group1 = VGGroup2
                else:
                    if '_L_' in VGGroup1:
                        Group1 = VGGroup1
                    elif '_L_' in VGGroup2:
                        Group1 = VGGroup2

            elif x < 0:
                if '_C_' in VGGroup1:
                    Group1 = VGGroup1
                elif '_C_' in VGGroup2:
                    Group1 = VGGroup2
                else:
                    if '_R_' in VGGroup1:
                        Group1 = VGGroup1
                    elif '_R_' in VGGroup2:
                        Group1 = VGGroup2
        except IndexError:
            Group1 = VGNames[int(checkLineVGIndex[0], 16)]
            pass

        try:
            VGGroup1 = VGNames2[int(checkLineVGIndex[1], 16)]
            VGGroup2 = VGNames[int(checkLineVGIndex[1], 16)]
            if x > 0:
                if '_C_' in VGGroup1:
                    Group2 = VGGroup1
                elif '_C_' in VGGroup2:
                    Group2 = VGGroup2

                else:
                    if '_L_' in VGGroup1:
                        Group2 = VGGroup1
                    elif '_L_' in VGGroup2:
                        Group2 = VGGroup2

            elif x < 0:
                if '_C_' in VGGroup1:
                    Group2 = VGGroup1
                elif '_C_' in VGGroup2:
                    Group2 = VGGroup2
                else:
                    if '_R_' in VGGroup1:
                        Group2 = VGGroup1
                    elif '_R_' in VGGroup2:
                        Group2 = VGGroup2

        except IndexError:
            Group2 = VGNames[int(checkLineVGIndex[1], 16)]
            pass

        try:
            VGGroup1 = VGNames2[int(checkLineVGIndex[2], 16)]
            VGGroup2 = VGNames [int(checkLineVGIndex[2], 16)]
            if x > 0:
                if '_C_' in VGGroup1:
                    Group3 = VGGroup1
                elif '_C_' in VGGroup2:
                    Group3 = VGGroup2
                else:
                    if '_L_' in VGGroup1:
                        Group3 = VGGroup1
                    elif '_L_' in VGGroup2:
                        Group3 = VGGroup2

            elif x < 0:
                if '_C_' in VGGroup1:
                    Group3 = VGGroup1
                elif '_C_' in VGGroup2:
                    Group3 = VGGroup2
                else:
                    if '_R_' in VGGroup1:
                        Group3 = VGGroup1
                    elif '_R_' in VGGroup2:
                        Group3 = VGGroup2

        except IndexError:
            Group3 = VGNames[int(checkLineVGIndex[2], 16)]
            pass

        try:
            VGGroup1 = VGNames2[int(checkLineVGIndex[3], 16)]
            VGGroup2 = VGNames [int(checkLineVGIndex[3], 16)]
            if x > 0:
                if '_C_' in VGGroup1:
                    Group4 = VGGroup1
                elif '_C_' in VGGroup2:
                    Group4 = VGGroup2

                else:
                    if '_L_' in VGGroup1:
                        Group4 = VGGroup1
                    elif '_L_' in VGGroup2:
                        Group4 = VGGroup2

            elif x < 0:
                if '_C_' in VGGroup1:
                    Group4 = VGGroup1
                elif '_C_' in VGGroup2:
                    Group4 = VGGroup2
                else:
                    if '_R_' in VGGroup1:
                        Group4 = VGGroup1
                    elif '_R_' in VGGroup2:
                        Group4 = VGGroup2
        except IndexError:
            Group4 = VGNames[int(checkLineVGIndex[3], 16)]
            pass
    else:
        Group1 = VGNames[int(checkLineVGIndex[0], 16)]
        Group2 = VGNames[int(checkLineVGIndex[1], 16)]
        Group3 = VGNames[int(checkLineVGIndex[2], 16)]
        Group4 = VGNames[int(checkLineVGIndex[3], 16)]

    checkLineWeights = line[28:34]
    before1 = hexToHalfFloat(checkLineWeights[4:6])
    before2 = hexToHalfFloat(checkLineWeights[2:4])
    before3 = hexToHalfFloat(checkLineWeights[0:2])

    w4 = 1 - (before1 + before2 + before3)
    w2 = before2
    w1 = before3
    w3 = 1 - (w4 + w2 + w1)

    tempVG = []

    if w1 != 0.0 and Group1 is not None:
        tempVG.append([Group1, w1])
    if w2 != 0.0 and Group2 is not None:
        tempVG.append([Group2, w2])
    if w3 != 0.0 and Group3 is not None:
        tempVG.append([Group3, w3])
    if w4 != 0.0 and Group4 is not None:
        tempVG.append([Group4, w4])

    return tempVG

def split_Grouper(HEX: str, OFF, COUNT, AFF, AOUNT):
    tList = HEX[OFF:].split(' ')
    tList = tList[:int(COUNT) * 6]
    ttList = []
    RETURNING = []
    for i in range(1, len(tList), 2):
        ttList.append(tList[i - 1:i + 1])
    for item in ttList:
        ttList[ttList.index(item)] = int(item[1] + item[0], 16) + 1
    RETURNING.append(ttList)

    tList = HEX[AFF:].split(' ')
    tList = tList[:int(AOUNT) * 6]
    ttList2 = []
    for i in range(1, len(tList), 2):
        ttList2.append(tList[i - 1:i + 1])
    for item in ttList2:
        ttList2[ttList2.index(item)] = int(item[1] + item[0], 16) + 1
    RETURNING.append(ttList2)

    return RETURNING

def left_or_right(group:str,vertX):
    if '_r_' in group.lower():
        if vertX < 0:
            print('Correct Right')
            return group
        else:
            print('Incorrect, Left')
            return group.replace('_R_','_L_')
    elif '_l_' in group.lower():
        if vertX > 0:
            print('Correct Left')
            return group
        else:
            print('Incorrect, Right')
            return group.replace('_L_','_R_')
    pass


def Reader(fileBytes):
    emdfileHex = hexify(fileBytes)
    hexList = emdfileHex.split(' ')
    EMDData = EMD(hexList)
    returnGroups = []
    for ModelInd in range(0, len(EMDData.Models)):
        newGroup = EmdGroup(EMDData.Models[ModelInd].name)
        #print(newGroup.name)
        newGroup.subMeshes = EMDData.SubMeshes[ModelInd]
        newGroup.meshes = []
        groupVertClusters = []
        for VertexInd in EMDData.Vertices[ModelInd]:
            groupVertClusters.append(VertexInd)

        groupTrianClusters = []
        for TriInd in EMDData.Triangles[ModelInd]:
            groupTrianClusters.append(TriInd)


        # print(tempVerts)
        for ind in range(0, len(newGroup.subMeshes)):
            newGroup.meshCount = len(newGroup.subMeshes[ind])
            for SubMeshInd in range(0,len(newGroup.subMeshes[ind])):
                newMesh = EmdMesh()
                newMesh.MeshName = newGroup.subMeshes[ind][SubMeshInd].name
                #print(newMesh.MeshName)
                newMesh.vertices = groupVertClusters[ind][SubMeshInd]
                #print('Len Verts',len(newMesh.vertices))
                TriCluster = groupTrianClusters[ind][SubMeshInd]
                #print('T Cluster Len',len(TriCluster))
                #print('V Cluster Len',len(groupVertClusters[ind]))

                tempFaces = []
                if len(TriCluster) == 1:
                    tempFaces.extend(groupTrianClusters[ind][SubMeshInd][0].Faces)
                    bones = groupTrianClusters[ind][SubMeshInd][0].bone_names
                    #print()
                    for vertexItem in newMesh.vertices:
                        vertexItem.vgNames = [bones[vertexItem.vgIndexes[0]],
                                              bones[vertexItem.vgIndexes[1]],
                                              bones[vertexItem.vgIndexes[2]],
                                              bones[vertexItem.vgIndexes[3]]]
                    newMesh.vertex_group_names = bones

                elif len(TriCluster) > 1:
                    tempBones = []
                    for clustInd in groupTrianClusters[ind][SubMeshInd]:
                        tempFaces.extend(clustInd.Faces)
                        bones = clustInd.bone_names
                        tempBones.extend(bones)
                        #print(clustInd.bone_names)
                        for face in clustInd.Faces:#groupTrianClusters[ind][SubMeshInd][0].Faces:
                            Vert1_vgIndexes = newMesh.vertices[face[0]].vgIndexes
                            Vert2_vgIndexes = newMesh.vertices[face[1]].vgIndexes
                            Vert3_vgIndexes = newMesh.vertices[face[2]].vgIndexes
                            if not len(newMesh.vertices[face[0]].vgNames):
                                newMesh.vertices[face[0]].vgNames = [bones[Vert1_vgIndexes[0]], bones[Vert1_vgIndexes[1]],
                                                                 bones[Vert1_vgIndexes[2]], bones[Vert1_vgIndexes[3]]]
                            if not len(newMesh.vertices[face[1]].vgNames):
                                newMesh.vertices[face[1]].vgNames = [bones[Vert2_vgIndexes[0]], bones[Vert2_vgIndexes[1]],
                                                                 bones[Vert2_vgIndexes[2]], bones[Vert2_vgIndexes[3]]]
                            if not len(newMesh.vertices[face[2]].vgNames):
                                newMesh.vertices[face[2]].vgNames = [bones[Vert3_vgIndexes[0]], bones[Vert3_vgIndexes[1]],
                                                                 bones[Vert3_vgIndexes[2]], bones[Vert3_vgIndexes[3]]]

                    newMesh.vertex_group_names = tempBones

                for vertexItem in newMesh.vertices:
                    for vgItem in range(0, len(vertexItem.vgNames)):
                        if vertexItem.location[0] > 0.0 and '_R_' in vertexItem.vgNames[vgItem]:
                            vertexItem.vgNames[vgItem] = vertexItem.vgNames[vgItem].replace('_R_', '_L_')
                        
                        elif vertexItem.location[0] < 0.0 and '_L_' in vertexItem.vgNames[vgItem]:
                            vertexItem.vgNames[vgItem] = vertexItem.vgNames[vgItem].replace('_L_', '_R_')

                newMesh.faces = tempFaces
                #print('Len Faces',len(newMesh.faces))
                #tempGroups = []
                #for clustInd in groupTrianClusters[ind][SubMeshInd]:
                #    tempGroups.append(clustInd.bone_names)
                #for vert in newMesh.vertices:
                #    if not len(vert.vgNames):
                #
                #        pass
                newGroup.meshes.append(newMesh)
        returnGroups.append(newGroup)
    #for item in EMDData.Models:
    #    print(item.name)
    return returnGroups

