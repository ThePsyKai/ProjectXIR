from .fileUtil import (str2hex,hex2str,hexify,fileReader,hexList2hexStrList)
import re
from .handlingHex import vertHex2Float
from .emd_file_obj import (EmdMesh,
                           EmdModel)

def getVertexXYZ(vL):
    vertices = []
    for vert in vL:
        xCoor = vert[0:4]
        yCoor = vert[4:8]
        zCoor = vert[8:12]
        vertices.append([xCoor, yCoor, zCoor])
    return vertices

def get_face_offset(HEX):
    #check = ['mark', 'skin', 'shirts', 'dougi_syatu']
    #checkBYTES = []
    #for i in check:
    #    print(i)
    #    checkBYTES.append(fileUtil.str2hex(i))
    tList = []
    tNum = 0
    test = ['00 00 02 00 01 00','00 00 01 00 02 00']

    t2 = 0
    for i in test:
        while i in HEX:
            try:
                tNum = HEX.index(i, tNum)
                tList.append(tNum)
                tNum+= len(i)
            except ValueError as err:
                if str(err) == 'substring not found':
                    break
                else:
                    raise err
    return tList

def get_face_count1(HEX: str, OFFSET):
    tList = HEX[OFFSET:].split(' ')
    tVal = 0
    vertexCount = 0
    for i in range(1,len(tList),2):
        if tList[i] == '00' or tList[i] == '01' or tList[i] == '02' or tList[i] == '03' or tList[i] == '04' or tList[i] == '05' or tList[i] == '06' or tList[i] == '07' or tList[i] == '08' or tList[i] == '09':
            if int(str(tList[i-1]),16)+1 > vertexCount:
                vertexCount = int(str(tList[i-1]),16)+1
            pass
        else:
            tVal = i
            break
    return int(tVal/6)

def get_face_count(HEX: str, OFFSET):
    tList = HEX[OFFSET:].split(' ')
    tVal = 0
    vertexCount = 0
    diamondCheck = []
    priorFace = []
    for i in range(1,len(tList),2):
        if len(priorFace) < 3:
            priorFace.append(int(str(tList[i]) + str(tList[i - 1]), 16) + 1)
        else:
            diamondCheck.append(priorFace)
            priorFace = [int(str(tList[i]) + str(tList[i - 1]), 16) + 1]

        if tList[i] == '00' or tList[i] == '01' or tList[i] == '02' or tList[i] == '03' or tList[i] == '04' or tList[i] == '05' or tList[i] == '06' or tList[i] == '07' or tList[i] == '08' or tList[i] == '09':
            if int(str(tList[i])+str(tList[i-1]),16)+1 >= vertexCount:
                vertexCount = int(str(tList[i])+str(tList[i-1]),16)+1
            pass
        else:
            tVal = i
            break
    diamond = []
    for x in range(len(diamondCheck)-1,0,-1):
        if diamondCheck[x][1] == 1:
            diamond.append(diamondCheck[x])
        elif diamondCheck[x][0] == 1 and diamondCheck[x][2] == 1:
            diamond.append(diamondCheck[x])
        else:
            break
    return int(tVal/6) - len(diamond)

def get_vertex_count(FaceHex, off, count):
    #print("Known Count:", count)
    #print(FaceHex[off:off + ((int(count)) * 6)-1])
    tList = FaceHex[off:].split(' ')
    tList = tList[:int(count) * 6]
    ttList = []
    for i in range(1,len(tList),2):
        ttList.append(tList[i-1:i+1])
    for item in ttList:
        ttList[ttList.index(item)] = int(item[1]+item[0] ,16)+1
    ttList.sort()
    tNum = 0
    for k in ttList:
        if ttList.index(k)+1 < len(ttList):
            if ttList[ttList.index(k)+1]-k == 1 or ttList[ttList.index(k)+1]-k == 0:
                pass
            elif ttList[ttList.index(k)+1]-k > 1:
                tNum = ttList.index(k)
                break
    if tNum == 0:
        pass
    else:
        ttList = ttList[:tNum]
    #print(ttList)
    return ttList[-1]

def findBoneData(HEX: str):
    tList = []
    lastList = 0
    validBonesHex = ['62 5f 43 5f 42 61 73 65', '62 5f 43 5f 50 65 6c 76 69 73', '62 5f 52 5f 4c 65 67 31', '62 5f 52 5f 4c 65 67 32', '62 5f 52 5f 46 6f 6f 74', '67 5f 52 5f 46 6f 6f 74', '62 5f 52 5f 54 6f 65', '62 5f 52 5f 4b 6e 65 65', '62 5f 4c 5f 4c 65 67 31', '62 5f 4c 5f 4c 65 67 32', '62 5f 4c 5f 46 6f 6f 74', '67 5f 4c 5f 46 6f 6f 74', '62 5f 4c 5f 54 6f 65', '62 5f 4c 5f 4b 6e 65 65', '67 5f 43 5f 50 65 6c 76 69 73', '62 5f 43 5f 53 70 69 6e 65 31', '62 5f 43 5f 53 70 69 6e 65 32', '62 5f 43 5f 43 68 65 73 74', '62 5f 52 5f 53 68 6f 75 6c 64 65 72', '62 5f 52 5f 41 72 6d 31', '62 5f 52 5f 45 6c 62 6f 77', '62 5f 52 5f 41 72 6d 32', '62 5f 52 5f 48 61 6e 64', '68 5f 52 5f 4d 69 64 64 6c 65 31', '68 5f 52 5f 4d 69 64 64 6c 65 32', '68 5f 52 5f 4d 69 64 64 6c 65 33', '67 5f 52 5f 48 61 6e 64', '68 5f 52 5f 50 69 6e 6b 79 31', '68 5f 52 5f 50 69 6e 6b 79 32', '68 5f 52 5f 50 69 6e 6b 79 33', '68 5f 52 5f 52 69 6e 67 31', '68 5f 52 5f 52 69 6e 67 32', '68 5f 52 5f 52 69 6e 67 33', '68 5f 52 5f 49 6e 64 65 78 31', '68 5f 52 5f 49 6e 64 65 78 32', '68 5f 52 5f 49 6e 64 65 78 33', '68 5f 52 5f 54 68 75 6d 62 31', '68 5f 52 5f 54 68 75 6d 62 32', '68 5f 52 5f 54 68 75 6d 62 33', '62 5f 52 5f 41 72 6d 52 6f 6c 6c', '62 5f 52 5f 41 72 6d 48 65 6c 70 65 72', '62 5f 52 5f 41 72 6d 6f 72 50 61 72 74 73', '62 5f 4c 5f 53 68 6f 75 6c 64 65 72', '62 5f 4c 5f 41 72 6d 31', '62 5f 4c 5f 41 72 6d 32', '62 5f 4c 5f 48 61 6e 64', '68 5f 4c 5f 4d 69 64 64 6c 65 31', '68 5f 4c 5f 4d 69 64 64 6c 65 32', '68 5f 4c 5f 4d 69 64 64 6c 65 33', '67 5f 4c 5f 48 61 6e 64', '68 5f 4c 5f 50 69 6e 6b 79 31', '68 5f 4c 5f 50 69 6e 6b 79 32', '68 5f 4c 5f 50 69 6e 6b 79 33', '68 5f 4c 5f 52 69 6e 67 31', '68 5f 4c 5f 52 69 6e 67 32', '68 5f 4c 5f 52 69 6e 67 33', '68 5f 4c 5f 49 6e 64 65 78 31', '68 5f 4c 5f 49 6e 64 65 78 32', '68 5f 4c 5f 49 6e 64 65 78 33', '68 5f 4c 5f 54 68 75 6d 62 31', '68 5f 4c 5f 54 68 75 6d 62 32', '68 5f 4c 5f 54 68 75 6d 62 33', '62 5f 4c 5f 41 72 6d 52 6f 6c 6c', '62 5f 4c 5f 45 6c 62 6f 77', '62 5f 4c 5f 41 72 6d 48 65 6c 70 65 72', '62 5f 4c 5f 41 72 6d 6f 72 50 61 72 74 73', '62 5f 43 5f 4e 65 63 6b 31', '62 5f 43 5f 48 65 61 64', '67 5f 43 5f 48 65 61 64', '66 5f 43 5f 46 61 63 65 52 6f 6f 74', '66 5f 4c 5f 45 79 65 49 6e 6e 65 72 43 6f 72 6e 65 72', '66 5f 52 5f 45 79 65 43 6f 72 6e 65 72', '66 5f 4c 5f 45 79 65 53 6f 63 6b 65 74', '66 5f 43 5f 54 6f 6f 74 68 54 6f 70', '66 5f 43 5f 4a 61 77', '66 5f 4c 5f 4d 6f 75 74 68 42 6f 74 74 6f 6d', '66 5f 43 5f 4d 6f 75 74 68 42 6f 74 74 6f 6d', '66 5f 52 5f 4d 6f 75 74 68 42 6f 74 74 6f 6d', '66 5f 43 5f 54 6f 6e 67 75 65 31', '66 5f 43 5f 54 6f 6e 67 75 65 32', '66 5f 43 5f 54 6f 6e 67 75 65 33', '66 5f 43 5f 54 6f 6e 67 75 65 34', '66 5f 43 5f 54 6f 6f 74 68 42 6f 74 74 6f 6d', '66 5f 4c 5f 45 79 65 43 6f 72 6e 65 72', '66 5f 4c 5f 45 79 65 42 72 6f 77 73 31', '66 5f 4c 5f 45 79 65 42 72 6f 77 73 32', '66 5f 4c 5f 45 79 65 42 72 6f 77 73 33', '66 5f 4c 5f 45 79 65 42 72 6f 77 73 48 61 69 72 33', '66 5f 4c 5f 45 79 65 42 72 6f 77 73 48 61 69 72 32', '66 5f 4c 5f 45 79 65 42 72 6f 77 73 48 61 69 72 31', '66 5f 4c 5f 43 68 65 65 6b 54 6f 70', '66 5f 52 5f 45 79 65', '66 5f 52 5f 45 79 65 49 72 69 73', '66 5f 4c 5f 45 79 65', '66 5f 4c 5f 45 79 65 49 72 69 73', '66 5f 43 5f 4a 61 77 48 61 6c 66', '66 5f 4c 5f 4d 6f 75 74 68 43 6f 72 6e 65 72 73', '66 5f 4c 5f 43 68 65 65 6b 42 6f 74 74 6f 6d', '66 5f 52 5f 43 68 65 65 6b 42 6f 74 74 6f 6d', '66 5f 52 5f 4d 6f 75 74 68 43 6f 72 6e 65 72 73', '66 5f 43 5f 4e 6f 73 65 54 6f 70', '66 5f 43 5f 4d 6f 75 74 68 54 6f 70', '66 5f 4c 5f 45 79 65 6c 69 64 42 6f 74 74 6f 6d', '66 5f 4c 5f 45 79 65 6c 69 64 54 6f 70', '66 5f 52 5f 43 68 65 65 6b 54 6f 70', '66 5f 52 5f 45 79 65 49 6e 6e 65 72 43 6f 72 6e 65 72', '66 5f 52 5f 45 79 65 53 6f 63 6b 65 74', '66 5f 52 5f 45 79 65 6c 69 64 42 6f 74 74 6f 6d', '66 5f 52 5f 45 79 65 6c 69 64 54 6f 70', '66 5f 52 5f 45 79 65 42 72 6f 77 73 31', '66 5f 52 5f 45 79 65 42 72 6f 77 73 32', '66 5f 52 5f 45 79 65 42 72 6f 77 73 33', '66 5f 52 5f 45 79 65 42 72 6f 77 73 48 61 69 72 33', '66 5f 52 5f 45 79 65 42 72 6f 77 73 48 61 69 72 32', '66 5f 52 5f 45 79 65 42 72 6f 77 73 48 61 69 72 31', '66 5f 52 5f 4d 6f 75 74 68 54 6f 70', '66 5f 4c 5f 4d 6f 75 74 68 54 6f 70', '62 5f 52 5f 4c 65 67 48 65 6c 70 65 72', '62 5f 4c 5f 4c 65 67 48 65 6c 70 65 72', '67 5f 78 5f 4c 4e 44', '67 5f 78 5f 43 41 4d', '78 5f 78 5f 53 6b 69 6e 52 6f 6f 74', '53 43 44 5f 48 61 69 72 5f 30 5f 30', '53 43 44 5f 48 61 69 72 5f 30 5f 31', '53 43 44 5f 48 61 69 72 5f 31 5f 30', '53 43 44 5f 48 61 69 72 5f 31 5f 31', '53 43 44 5f 48 61 69 72 5f 32 5f 30', '53 43 44 5f 48 61 69 72 5f 32 5f 31', '53 43 44 5f 48 61 69 72 5f 33 5f 30', '53 43 44 5f 48 61 69 72 5f 33 5f 31', '53 43 44 5f 48 61 69 72 5f 34 5f 30', '53 43 44 5f 48 61 69 72 5f 34 5f 31', '53 43 44 5f 6f 62 69 5f 30 5f 30', '53 43 44 5f 6f 62 69 5f 30 5f 31', '53 43 44 5f 6f 62 69 5f 30 5f 32', '53 43 44 5f 6f 62 69 5f 31 5f 30', '53 43 44 5f 6f 62 69 5f 31 5f 31', '53 43 44 5f 6f 62 69 5f 31 5f 32', '78 5f 52 5f 41 72 6d 5a 6f 6f 6d 36', '78 5f 52 5f 41 72 6d 5a 6f 6f 6d 37', '78 5f 52 5f 41 72 6d 5a 6f 6f 6d 38', '78 5f 52 5f 41 72 6d 5a 6f 6f 6d 39', '78 5f 52 5f 41 72 6d 5a 6f 6f 6d 31 30', '78 5f 52 5f 41 72 6d 5a 6f 6f 6d 31', '78 5f 52 5f 41 72 6d 5a 6f 6f 6d 32', '78 5f 52 5f 41 72 6d 5a 6f 6f 6d 33', '78 5f 52 5f 41 72 6d 5a 6f 6f 6d 34', '78 5f 52 5f 41 72 6d 5a 6f 6f 6d 35', '78 5f 4c 5f 41 72 6d 5a 6f 6f 6d 36', '78 5f 4c 5f 41 72 6d 5a 6f 6f 6d 37', '78 5f 4c 5f 41 72 6d 5a 6f 6f 6d 38', '78 5f 4c 5f 41 72 6d 5a 6f 6f 6d 39', '78 5f 4c 5f 41 72 6d 5a 6f 6f 6d 31 30', '78 5f 4c 5f 41 72 6d 5a 6f 6f 6d 31', '78 5f 4c 5f 41 72 6d 5a 6f 6f 6d 32', '78 5f 4c 5f 41 72 6d 5a 6f 6f 6d 33', '78 5f 4c 5f 41 72 6d 5a 6f 6f 6d 34', '78 5f 4c 5f 41 72 6d 5a 6f 6f 6d 35', '62 5f 52 5f 54 6f 65 4d 69 64 64 6c 65 31', '62 5f 52 5f 54 6f 65 4d 69 64 64 6c 65 32', '62 5f 52 5f 54 6f 65 4d 69 64 64 6c 65 33', '62 5f 52 5f 54 6f 65 50 69 6e 6b 79 31', '62 5f 52 5f 54 6f 65 50 69 6e 6b 79 32', '62 5f 52 5f 54 6f 65 50 69 6e 6b 79 33', '62 5f 52 5f 54 6f 65 54 68 75 6d 62 31', '62 5f 52 5f 54 6f 65 54 68 75 6d 62 32', '62 5f 52 5f 54 6f 65 54 68 75 6d 62 33', '62 5f 4c 5f 54 6f 65 4d 69 64 64 6c 65 31', '62 5f 4c 5f 54 6f 65 4d 69 64 64 6c 65 32', '62 5f 4c 5f 54 6f 65 4d 69 64 64 6c 65 33', '62 5f 4c 5f 54 6f 65 50 69 6e 6b 79 31', '62 5f 4c 5f 54 6f 65 50 69 6e 6b 79 32', '62 5f 4c 5f 54 6f 65 50 69 6e 6b 79 33', '62 5f 4c 5f 54 6f 65 54 68 75 6d 62 31', '62 5f 4c 5f 54 6f 65 54 68 75 6d 62 32', '62 5f 4c 5f 54 6f 65 54 68 75 6d 62 33', '58 5f 54 5f 54 41 49 4c 31', '58 5f 54 5f 54 41 49 4c 32', '58 5f 54 5f 54 41 49 4c 33', '58 5f 54 5f 54 41 49 4c 34', '58 5f 54 5f 54 41 49 4c 35', '58 5f 54 5f 54 41 49 4c 36', '58 5f 54 5f 54 41 49 4c 37', '58 5f 54 5f 54 41 49 4c 38', '58 5f 54 5f 54 41 49 4c 39', '58 5f 54 5f 54 41 49 4c 31 30', '53 43 44 5f 68 61 69 72 5f 30 5f 30', '53 43 44 5f 68 61 69 72 5f 30 5f 31', '53 43 44 5f 68 61 69 72 5f 30 5f 32']
    for bone in validBonesHex:
        tNum = 0
        tHEX = HEX
        while True:
            m = re.search(bone, tHEX)
            if m:
                if [int(list(m.span())[0]/3),int(list(m.span())[1]/3)] not in tList:
                    tList.append([int((list(m.span())[0]+tNum)/3),int((list(m.span())[1]+tNum)/3)])
                    tNum = list(m.span())[1]+tNum
                    tHEX = HEX[tNum:]
            elif m is None:
                #print(fileUtil.hex2str(bone), len(tList)-lastList)
                if len(tList) > lastList:
                    lastList = len(tList)
                break
    tList.sort()
    clusters = []
    ttList = []
    tVal2 = 0
    for B in tList:
        if tList.index(B) + 1 < len(tList):
            if tList[tList.index(B) + 1][0] - B[1] == 2:
                pass
            else:
                clusters.append(tList[int(tVal2):tList.index(B) + 1])
                tVal2 = tList.index(tList[tList.index(B) + 1])
        if tList.index(B) + 1 >= len(tList):
            clusters.append(tList[tList.index(B)])
    for x in clusters:
        clusters[clusters.index(x)] = x[-1]
    #if len(clusters) < lastList:
    #    checkBoneData(HEX[clusters[-1]])"""
    #print(clusters)
    return clusters

def offsetVertex(HEXSTR: str, OFFSET: int) -> int:
    latest = OFFSET
    latest = offsetConfirm(HEXSTR,latest)
    return latest

def offsetConfirm(HEXSTR: str, latest: int):
    check = False
    count0s = 0
    tLatest = latest
    tHEX =''
    tHEX += HEXSTR[latest+3:]
    for C in HEXSTR[latest+3:].split(' '):
        #print("C != '00':",C != '00'," count0s:",(count0s/2 == float(int(count0s/2))))
        if tHEX[0:3]!='00 ':
            hexT = HEXSTR[latest+1:]
            #print(len(HEXSTR[latest + 1:].split(' ')[HEXSTR[latest + 1:].split(' ').index(C):36 + HEXSTR[latest + 1:].split(' ').index(C)]), HEXSTR[latest + 1:].split(' ')[HEXSTR[latest + 1:].split(' ').index(C):36 + HEXSTR[latest + 1:].split(' ').index(C)])
            #print(hexT.split(' ')[hexT.split(' ').index(C):36 + hexT.split(' ').index(C)])
            if hexT.split(' ')[hexT.split(' ').index(C):36 + hexT.split(' ').index(C)][-1] == '00':
                #print(HEXSTR[latest + 1:].split(' ')[HEXSTR[latest + 1:].split(' ').index(C):36 + HEXSTR[latest + 1:].split(' ').index(C)])
                latest += HEXSTR[latest:].index(C)
                check = True
                break
            else:
                latest += HEXSTR[latest:].index(C) + 3
        else:
            tHEX = tHEX[3:]
        if check:
            break
    return latest

def faceData(HEX: str, off: int, count, off2: int=None, count2: int=None):
    tList = HEX.split(' ')[int(off/3):int(off/3) + (count * 6)]
    returnList = []
    tL = []
    for i in range(0,len(tList),2):
        tL.append(int(tList[i+1]+tList[i],16))
        if len(tL) == 3:
            returnList.append(tuple(tL))
            tL = []

    if off2 and count2:
        print('Accounting for Split')
        tList = HEX.split(' ')[int(off2 / 3):int(off2 / 3) + (count2 * 6)]
        returnList2 = []
        tL = []
        for i in range(0, len(tList), 2):
            tL.append(int(tList[i + 1] + tList[i], 16))
            if len(tL) == 3:
                returnList2.append(tuple(tL))
                tL = []
        returnList.extend(returnList2)
    return returnList

def facesToEdges(faceList):
    edgeList = []
    for i in faceList:
        edgeList.append(tuple((i[0],i[1])))
        edgeList.append(tuple((i[0],i[2])))
        edgeList.append(tuple((i[1],i[2])))
    return edgeList

def blenderFacesList(fList):
    returnList = []
    for i in range(0,len(fList)):
        returnList.append(tuple((0+i*3,1+i*3,2+i*3)))
    return returnList

def vertexLines(HEX: str, off: int, count: int) -> list:
    htemp = HEX.split(' ')
    vLTemp = []
    vTemp = []
    for i in htemp[off:off+(count*36)]:
        vTemp.append(i)
        if len(vTemp) == 36:
            vLTemp.append(vTemp)
            vTemp = []
    return vLTemp






def Reader(fileBytes):
    GOKTest = EmdModel()
    get_face = get_face_offset(fileHex)
    faceOffsets = get_face[1]
    meshNames = get_mesh_names(fileHex, get_face[0])  # print(faceOffsets)
    # offsetLocations = findBoneData(fileHex)
    meshes = []
    for f in faceOffsets:
        newMesh = EmdMesh()
        newMesh.MeshName = meshNames[faceOffsets.index(f)]
        print(newMesh.MeshName)
        faceCount = get_face_count(fileHex, f)

        splitCheck = is_Split(fileHex.split(' '), int(f / 3), faceCount)
        print(splitCheck)
        if splitCheck:
            alt = goAroundSplit(fileHex.split(' '), int(f / 3), faceCount)
            altOffset = alt[0] * 3
            altCount = alt[1]
            vertCount = get_vertex_count(fileHex, f, faceCount, off2=altOffset, count2=altCount)
            newMesh.vertexes.offset = get_vertex_offset(HEXSTR=fileHex, FACEOFF=int(altOffset / 3), FACECOUNT=altCount)

            pass
        else:
            vertCount = get_vertex_count(fileHex, f, faceCount)
            newMesh.vertexes.offset = get_vertex_offset(HEXSTR=fileHex, FACEOFF=int(f / 3), FACECOUNT=faceCount)
        while True:
            vertVerify = verify_vertex_offset(HEX=fileHex, OFF=newMesh.vertexes.offset)
            if not vertVerify:
                newMesh.vertexes.offset += 3
            else:
                break
        print('----------------------------------------------------------')

        # newMesh.vertexes.offset = offsetVertex(fileHex, OFFSET=0)
        print('Vertex Offset:', str(int(newMesh.vertexes.offset / 3)))
        print('Vertex Count:  ' + str(vertCount))
        print('Padding:      ', newMesh.vertexes.padding)
        #    try:
        #        # print(offsetLocations[faceOffsets.index(f)] * 3)
        #        if type(offsetLocations[faceOffsets.index(f)]) == list:
        #            newMesh.vertexes.offset = offsetVertex(fileHex, OFFSET=offsetLocations[faceOffsets.index(f)][-1] * 3)
        #            print('Vertex Offset:', str(int(newMesh.vertexes.offset / 3)))
        #            print('Vertex Count:  ' + str(vertCount))
        #            print('Padding:      ', newMesh.vertexes.padding)
        #
        #        elif type(offsetLocations[faceOffsets.index(f)]) == int:
        #            newMesh.vertexes.offset = offsetVertex(fileHex, OFFSET=offsetLocations[faceOffsets.index(f)] * 3)
        #            print('Vertex Offset:', str(int(newMesh.vertexes.offset / 3)))
        #            print('Vertex Count:  ' + str(vertCount))
        #            print('Padding:      ', newMesh.vertexes.padding)
        #
        #    except IndexError as err:
        #        if str(err) == 'list index out of range':
        #            print('Vertex Offset:', "???" + '\nVertex Count: ', "???")
        #            print("Face/Vertex list length mismatch")
        #        else:
        #            raise err
        newMesh.faces.offset = f
        print('Face Offset:  ', str(int(newMesh.faces.offset / 3)))
        print('Face Count:    ' + str(faceCount))
        print('Padding:      ', newMesh.faces.padding)
        if splitCheck:
            print('Alt Offset:   ', str(int(altOffset / 3)))
            print('Alt Count:     ' + str(altCount))
            print('Padding:      ', newMesh.faces.padding)
        # offsetLocal = int(f/3) + int(len(faceEndsets[faceOffsets.index(f)]))
        # offsetLocation = findBoneData(fileHex[offsetLocal:])
        print('----------------------------------------------------------')
        vertLines = vertexLines(fileHex, int(newMesh.vertexes.offset / 3), vertCount)

        vertices = getVertexXYZ(vertLines)
        vertexes = vertHex2Float(vertices)
        newMesh.vertexes.cloud = vertHex2Float(vertices)
        if splitCheck:
            newMesh.faces.cloud = faceData(fileHex, f, faceCount, off2=altOffset, count2=altCount)
        else:
            newMesh.faces.cloud = faceData(fileHex, f, faceCount)
        faces = newMesh.faces.cloud
        edges = []
        edges.extend(facesToEdges(faces))
        ###if len(faces) == faceCount:
        ###
        ###    pass
        ###elif len(faces) > faceCount:
        ###    faces = faces[:faceCount]
        ###    edges.extend(facesToEdges(faces))
        ###elif len(faces) < faceCount:
        ###    print('Error')
        ###    edges.clear()
        ###    faces.clear()
        GOKTest.meshes.append(newMesh)
        # print('Vertices:',vertexes)
        print('VertCount:', len(vertexes))
        # print('Edges:',edges)
        print('EdgeCount:', len(edges))
        # print('Faces:',faces)
        print('FaceCount:', len(faces))
        meshes.append([newMesh.vertexes.cloud, edges, newMesh.faces.cloud])
        #print('=============================')
        #print(meshes[meshes.index([vertexes, edges, faces])][0])
        #print('=============================')
        #print(meshes[meshes.index([vertexes, edges, faces])][1])
        #print('=============================')
        #print(meshes[meshes.index([vertexes, edges, faces])][2])
    return meshes