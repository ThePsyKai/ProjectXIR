


def Write_EMM(EMMName):
    pass