import traceback
from typing import *
from .fileUtil import *
import numpy as np

class EskArmature:
    def __init__(self):
        self.name       = ''
        self.bones      = []            #type: List[Bone]




class EskBone:
    def __init__(self):
        self.name       = ''            #type: str
        self.XYZ        = []
        self.ORI        = ()
        self.SCA        = ()
        self.ATM        = ()
        self.ATML1      = []
        self.ATML2      = []
        self.ATML3      = []
        self.ATML4      = []
        self.parent     = None

class LocationCloud:
    def __init__(self):
        self.cloud = []
        self.offset = 0
        self.padding = 52

class ESK_Header:
    def __init__(self,hlist):
        self.signature               = hex2str(hlist[0x00:0x04])
        self.endian                  = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x04:0x06],keepSpaces=False)),np.uint16)
        self.header_size             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x06:0x08],keepSpaces=False)),np.uint16)[0]
        self.version                 = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x08:0x0c],keepSpaces=False)),np.uint8)
        self.unknow_0                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x0c:0x10],keepSpaces=False)),np.uint32)
        self.offset_skeleton         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x10:0x14],keepSpaces=False)),np.uint32)[0]
        self.offset_nextPart         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x14:0x18],keepSpaces=False)),np.uint32)[0]
        self.unknow_1                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x18:0x1c],keepSpaces=False)),np.uint32)
        self.unknow_2                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x1c:0x20],keepSpaces=False)),np.uint32)

class ESK_Skeleton_Section:
    def __init__(self,hlist):
        self.number_bones            = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x00:0x02],keepSpaces=False)),np.uint16)[0]
        self.unknow_flag             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x02:0x04],keepSpaces=False)),np.uint16)
        self.offset_bonesHierarchy   = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x04:0x08],keepSpaces=False)),np.uint32)[0]
        self.offset_boneNames        = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x08:0x0c],keepSpaces=False)),np.uint32)[0]
        self.offset_relTransforms    = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x0c:0x10],keepSpaces=False)),np.uint32)[0]
        self.offset_absMatrices      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x10:0x14],keepSpaces=False)),np.uint32)[0]
        self.offset_IKs              = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x14:0x18],keepSpaces=False)),np.uint32)[0]
        self.offset_boneExtraInfo    = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x18:0x1c],keepSpaces=False)),np.uint32)[0]
        self.skeletonUniqueId_p1     = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x1c:0x20],keepSpaces=False)),np.uint32)
        print(self.skeletonUniqueId_p1)
        self.skeletonUniqueId_p2     = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x20:0x24],keepSpaces=False)),np.uint32)
        print(self.skeletonUniqueId_p2)

        self.bone_name_pointers = np.frombuffer(bytes.fromhex(hexList2hexStrList(
            hlist[self.offset_boneNames:self.offset_boneNames+(4*self.number_bones)],keepSpaces=False)),
            np.uint32)
        self.bone_names = np.array([hex2str(hlist[point:point+hlist[point:].index('00')]) for point in self.bone_name_pointers])

class ESK_Bone_Hierarchy:
    def __init__(self,hlist):
        self.parent_index            = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x00:0x02],keepSpaces=False)),np.uint16)
        self.child_index             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x02:0x04],keepSpaces=False)),np.uint16)
        self.sibling_index           = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x04:0x06],keepSpaces=False)),np.uint16)
        self.ik_flag                 = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x06:0x08],keepSpaces=False)),np.uint16)

class ESK_Bone_Relative_Transform:
    def __init__(self,hlist):
        self.position                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x00:0x10],keepSpaces=False)),np.float32)
        self.orientation             = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x10:0x20],keepSpaces=False)),np.float32)
        self.scale                   = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x20:0x30],keepSpaces=False)),np.float32)

class ESK_Bone_Absolute_Matrix:
    def __init__(self,hlist):
        self.m0                      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x00:0x10],keepSpaces=False)),np.float32)
        self.m1                      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x10:0x20],keepSpaces=False)),np.float32)
        self.m2                      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x20:0x30],keepSpaces=False)),np.float32)
        self.m3                      = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x30:0x40],keepSpaces=False)),np.float32)

class ESK_IK_Section:
    def __init__(self,hlist):
        #print(hlist[0x00:0x04])
        self.number_IkGroups         = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x00:0x04],keepSpaces=False)),np.uint32)[0]

class ESK_IK_Group:
    def __init__(self,hlist):
        self.typeGroup               = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x00:0x02],keepSpaces=False)),np.uint16)[0]
        self.sizeGroup               = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x02:0x04],keepSpaces=False)),np.uint16)[0]

        self.IK      = ESK_IK(hlist[0x04:0x06])
        self.IK_b    = ESK_IK_b(hlist[0x06:0x08])

class ESK_IK:
    def __init__(self,hlist):
        self.unknow_0                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x00:0x01],keepSpaces=False)),np.uint8)[0]
        self.number_relations        = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x01:0x02],keepSpaces=False)),np.uint8)[0]

class ESK_IK_b:
    def __init__(self,hlist):
        self.unknow_0                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x00:0x01],keepSpaces=False)),np.uint8)[0]
        self.unknow_1                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x01:0x02],keepSpaces=False)),np.uint8)[0]

class ESK_Bone_extraInfo:
    def __init__(self,hlist):
        self.unknow_0                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x00:0x02],keepSpaces=False)),np.uint16)      #16
        self.unknow_1                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x02:0x04],keepSpaces=False)),np.uint16)      #16
        self.unknow_2                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x04:0x06],keepSpaces=False)),np.uint16)      #16
        self.unknow_3                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x06:0x08],keepSpaces=False)),np.uint16)      #16

class ESK_IK_2:
    def __init__(self,hlist):
        self.number_bones            = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x00:0x04],keepSpaces=False)),np.uint32)      #32
        self.unknow_0                = np.frombuffer(bytes.fromhex(hexList2hexStrList(hlist[0x04:0x08],keepSpaces=False)),np.uint32)      #32


