from pathlib import Path
from typing import BinaryIO, Iterable, Sized, Union
import os

from .emd_file_obj import EmdModel
from .esk_file_obj import EskArmature

from .handlingHex import hexToHalfFloat

import bpy
import bmesh
import numpy as np
from mathutils import Vector, Matrix, Euler
import re
from math import *

def quaterion_to_euler(x,y,z,w):
    import math
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)

    X = math.degrees(math.atan2(t0,t1))

    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    Y = math.degrees(math.asin(t2))

    t3 = +2.0 * (w*z + x*y)
    t4 = +1.0 - 2.0 * (y*y + z*z)
    Z = math.degrees(math.atan2(t3,t4))

    return X, Y, Z

def esk_Locator(pathing, fileName):
    print()
    if 'scd.emd' in fileName:
        esk_file = pathing / (fileName[:-4] + '.esk')
        print(fileName)
        print(esk_file)
        if os.path.isfile(esk_file):
            return [esk_file ,fileName[:-4] + '.esk']
    else:
        esk_file = pathing / (fileName[:7] + '.esk')
        print(fileName)
        print(esk_file)
        if os.path.isfile(esk_file):
            return [esk_file ,fileName[:7] + '.esk']

def import_model(emd_file: BinaryIO, file_directory, parent_collection=None, file_name=None, Import_ESK=False):
    from .emd_reader import Reader as Read_emd

    if parent_collection is None:
        parent_collection = bpy.context.scene.collection
    if file_name is None:
        file_name = 'new_EMD'

    esk_bytes = esk_Locator(file_directory,file_name)

    if bpy.context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode="OBJECT", toggle=False)

    emd = EmdModel()
    readAlready = Read_emd(emd_file.read())
    emd.meshes = []
    for i in readAlready:
        for k in i.meshes:
            emd.meshes.append(k)
            print('Being Generated', k.MeshName)

    #print(len(meshes))
    current_emd_count = len([[collect.name, collect] for collect in bpy.data.collections if collect.name != 'Collection' and '.emd' in collect.name])
    new_collection = bpy.data.collections.new(file_name)
    new_collection['Xeno_Properties'] = {'CharCode'     : file_name[:3],
                                         'CharCode #'   : file_name[4:7],
                                         'Model Type'   : file_name[8:file_name.rindex('.')],
                                         'XenoState'    : 'XenoModelGroup'}
    new_collection['XenoModelGroup'] = True
    #file_properties = new_collection['Xeno_Properties']

    print('Character Code :', file_name[:3])
    print('CharCode Number:', file_name[4:7])
    print('Model Type     :', file_name[8:file_name.rindex('.')])
    


    bpy.context.scene.collection.children.link(new_collection)

    model_collections = readAlready
    core_object_list = []
    for i in bpy.context.selected_objects:
        i.select = False
    for group in model_collections:
        objectList = []
        Model_collection = bpy.data.collections.new(group.name)
        Model_collection['XenoMeshGroup'] = True
        Model_collection['Xeno_Properties'] = {'Name'       : group.name,
                                               'Parent'     : new_collection,
                                               'Mesh Index' : model_collections.index(group),
                                               'XenoState'  : 'XenoMeshGroup'}

        bpy.context.scene.collection.children[file_name].children.link(Model_collection)
        for mesh in group.meshes:
            current_mesh = bpy.data.meshes.new(name=mesh.MeshName)

            new_mesh = bmesh.new()
            vertexes = [Vert.location for Vert in mesh.vertices]
            faces = mesh.faces
            normals = [Vert.normal for Vert in mesh.vertices]

            for i in range(0, len(vertexes)):
                new_mesh.verts.new()
            new_mesh.verts.ensure_lookup_table()
            for i in range(0, len(vertexes)):
                new_mesh.verts[i].co = vertexes[i]
                new_mesh.verts[i].normal = normals[i]
            print(len(new_mesh.verts))

            for faceInd in range(0, len(faces)):
                face = (new_mesh.verts[faces[faceInd][0]],new_mesh.verts[faces[faceInd][1]],new_mesh.verts[faces[faceInd][2]])
                try:
                    new_mesh.faces.new(face)
                except:
                    pass
            new_mesh.to_mesh(current_mesh)
            new_object = bpy.data.objects.new(mesh.MeshName, current_mesh)
            new_object['Xeno_Properties'] = {'Name'     : new_object.name,
                                             'Parent'   : Model_collection,
                                             'Sub Index': 0,
                                             'XenoState': 'XenoSubmesh'}
            objectList.append(new_object)
            core_object_list.append(new_object)

        for i in range(0,len(objectList)):
            Model_collection.objects.link(objectList[i])
            objectList[i]['Xeno_Properties']['Sub Index'] = i


    for i in core_object_list:
        bpy.data.objects[i.name].rotation_euler[0] = 1.5708
        bpy.data.objects[i.name].rotation_euler[2] = -1.5708*2
        bpy.data.objects[i.name].scale.x = -1
        bpy.data.objects[i.name].select = True


        #/*------------------------------------UVs--------------------------------------\#

        mesh_data = bpy.data.objects[i.name].data
        ###
        NewMat = bpy.data.materials.new(i.name)
        mesh_data.materials.append(bpy.data.materials[NewMat.name])
        #print(mesh_data)
        mesh_data.uv_layers.new()
        uv_data = mesh_data.uv_layers[0].data
        vertex_indices = np.zeros((len(mesh_data.loops, )), dtype=np.uint32)
        mesh_data.loops.foreach_get('vertex_index', vertex_indices)

        UVs = [v.UV for v in emd.meshes[core_object_list.index(i)].vertices]

        try:
            UVcoors = [UVs[vertex_indices[k]] for k in range(0, len(vertex_indices))]
            for loop in range(0, len(uv_data)):
                uv_data[loop].uv = UVcoors[loop]
        except BaseException as err:
            print('UV Error for '+i.name)
            print(err)
            pass
        #\-----------------------------------------------------------------------------*/#

        #/*-------------------------------Vertex Groups--------------------------------\#
        Vertex_Group_Names = emd.meshes[core_object_list.index(i)].vertex_group_names
        groupVertCounts = []
        for gn in range(0,len(Vertex_Group_Names)):
            bpy.data.objects[i.name].vertex_groups.new(name=Vertex_Group_Names[gn])

        Vertices = emd.meshes[core_object_list.index(i)].vertices
        for v in Vertices:
            groups = v.vgNames
            weights = v.weights
            for w in range(0,4):
                if weights[w] == 0.0:
                    pass
                else:
                    print()
                    print('Name :',i.name)
                    print('Group:',groups[w])
                    try:
                        bpy.data.objects[i.name].vertex_groups[groups[w]].add([
                                emd.meshes[core_object_list.index(i)].vertices.index(v)],
                            weights[w], 'ADD')
                    except KeyError as err:
                        print(err)

        #\----------------------------------------------------------------------------*/#
    bpy.ops.object.shade_smooth()
    for i in bpy.context.selected_objects:
        i.select = False

    if Import_ESK:
        from .esk_reader import Reader as ReadEsk
        #esk_Locator(file_directory,file_name)
        parent_esk_file = esk_Locator(file_directory,file_name)#file_directory / file_name
        parent_esk_name = parent_esk_file[1]
        import_armature(esk_file=parent_esk_file[0].open('rb'), file_name=parent_esk_file[1],emd_objects=objectList)






def rot_edit_bone(bone,quaterion: np.array):
    #print(bone.name)
    #print(quaterion)
    #print(len(quaterion))
    euler = quaterion_to_euler(x=quaterion[0],
                               y=quaterion[1],
                               z=quaterion[2],
                               w=quaterion[3])
    #print(euler)
    old_head = bone.head.copy()

    R = Matrix.Rotation(radians(euler[0]),4,bone.x_axis.normalized())
    bone.transform(R,roll=True)

    R = Matrix.Rotation(radians(euler[1]), 4, bone.y_axis.normalized())
    bone.transform(R, roll=True)

    R = Matrix.Rotation(radians(euler[2]), 4, bone.z_axis.normalized())
    bone.transform(R, roll=True)

    offset_vec = -(bone.head - old_head)
    bone.head += offset_vec
    bone.tail += offset_vec
    pass

def import_armature(esk_file: BinaryIO, parent_collection=None, file_name=None,emd_objects=None):
    from .esk_reader import Reader as Read_esk
    if parent_collection is None:
        parent_collection = bpy.context.scene.collection
    if file_name is None:
        file_name = 'new_armature'

    esk = Read_esk(esk_file.read())
    esk.name = file_name

    new_collection = bpy.data.collections.new(file_name)
    bpy.context.scene.collection.children.link(new_collection)

    new_arm = bpy.data.armatures.new(esk.name)
    arm_object = bpy.data.objects.new(esk.name,new_arm)

    for i in bpy.context.selected_objects:
        i.select = False

    new_collection.objects.link(arm_object)

    bpy.context.view_layer.objects.active = bpy.data.objects[esk.name]
    bpy.data.objects[esk.name].select = True

    arm = bpy.context.active_object
    bpy.ops.object.mode_set(mode="EDIT",toggle=False)
    #print([item.name for item in esk.bones])
    for item in esk.bones:
        #print(item.name)
        new_bone = arm.data.edit_bones.new(item.name)
        #print(new_bone.name)

        if item.parent is not None:
            new_bone.parent = arm.data.edit_bones[item.parent.name]
        else:
            new_bone.parent = None
        itemMatrix = [item.ATML1,
                      item.ATML2,
                      item.ATML3,
                      item.ATML4]
        #print(itemMatrix)



        #itemMatrix = [tuple(itemMatrix[0]       ),
        #              tuple([0.0, 0.0, 0.0, 0.0]),
        #              tuple(itemMatrix[2]       ),
        #              tuple(itemMatrix[3]       )]
#        print("=============Matrix=============")
#        print(item.name)
#        print([keyItem for keyItem in item.ATML1])
#        print([keyItem for keyItem in item.ATML2])
#        print([keyItem for keyItem in item.ATML3])
#        print([keyItem for keyItem in item.ATML4])
#        print("================================")

        #new_bone.matrix = tuple(itemMatrix)
        #new_bone.tail.y = -item.XYZ[1] + .1
#        print('===========================')

        if new_bone.parent is not None:

            new_bone.head.x = item.XYZ[0] + new_bone.parent.head.x
            new_bone.head.y = item.XYZ[1] + new_bone.parent.head.y
            new_bone.head.z = item.XYZ[2] + new_bone.parent.head.z

            if 'h_' in new_bone.name:
                new_bone.tail = (new_bone.head.x,
                                 new_bone.head.y,
                                 new_bone.head.z + .1)
                if 'Thumb' in new_bone.name:
                    pass
                    #print('Absolute:', [(Abs * -Abs) for Abs in item.ATML1])
                    #print('Absolute:', [(Abs * -Abs) for Abs in item.ATML2])
                    #print('Absolute:', [(Abs * -Abs) for Abs in item.ATML3])
                    #print('Absolute:', [(item.ATML4[Abs] * -abs(new_bone.parent.head[Abs])) for Abs in range(0,3)])
                    #print(new_bone.head)
                    #print()

                    #print(item.XYZ)

            elif re.search('b_\w_Hand',new_bone.name) is not None:
                new_bone.tail = (new_bone.head.x,
                                 new_bone.head.y,
                                 new_bone.head.z + .1)
                new_bone.tail.z -= .2
            else:
                new_bone.tail = (new_bone.head.x,
                                 new_bone.head.y + .1,
                                 new_bone.head.z)
        else:
            new_bone.head.x = item.XYZ[0]
            new_bone.head.y = item.XYZ[1]
            new_bone.head.z = item.XYZ[2]

            new_bone.tail = (new_bone.head.x,
                             new_bone.head.y + .1,
                             new_bone.head.z)

        rot_edit_bone(new_bone,item.ORI)
        #if new_bone.parent is not None:

        #    new_bone.head.x = item.XYZ[0]       #(new_bone.parent.head.x + item.XYZ[0])
        #    new_bone.head.y = item.XYZ[1]       #(new_bone.parent.head.y + item.XYZ[1])
        #    new_bone.head.z = item.XYZ[2]       #(new_bone.parent.head.y + item.XYZ[2])

        #    new_bone.tail.x = item.XYZ[0]       #(new_bone.parent.head.x + item.XYZ[0])
        #    new_bone.tail.y = item.XYZ[1]+0.1   #(new_bone.parent.head.y + item.XYZ[1]) + 0.1
        #    new_bone.tail.z = item.XYZ[2]       #(new_bone.parent.head.y + item.XYZ[2])
        #    #new_bone.roll =
        #else:
        #    new_bone.head.x = item.XYZ[0]
        #    new_bone.head.y = item.XYZ[1]
        #    new_bone.head.z = item.XYZ[2]

        #    new_bone.tail.x = item.XYZ[0]
        #    new_bone.tail.y = item.XYZ[1] + 0.1
        #    new_bone.tail.z = item.XYZ[2]



        #print(quaterion_to_euler(x=item.ORI[1], y=item.ORI[2], z=item.ORI[3], w=item.ORI[0]))



    #if 'scd' not in esk.name.lower():
    #    for bone in arm.data.edit_bones:
    #        if 'pelvis' in bone.name.lower() and 'b' in bone.name.lower():
    #            #print(bone.name)
    #            for child in bone.children:
    #                #print(child.name)
    #                if 'spine' in child.name.lower():
    #                    bone.tail = child.head
    #                    break
    #        elif len(bone.children) and ('tongue' in bone.name.lower() or 'f' not in bone.name.lower()):
    #            if bone.name == 'b_R_Foot' or bone.name == 'b_L_Foot':
    #                for child in bone.children:
    #                    if 'toe' in child.name.lower():
    #                        bone.tail = child.head
    #                        break
    #            for child in bone.children:
    #                bone.tail = child.head

            #bone.tail
    #print([i.name for i in arm.data.edit_bones])
    bpy.ops.object.mode_set(mode="OBJECT", toggle=False)
    #print()
    #bpy.ops.object.mode_set(mode="EDIT", toggle=False)
    #print([i.parent.name for i in arm.data.edit_bones])
    bpy.ops.object.mode_set(mode="OBJECT", toggle=False)
    for i in arm.pose.bones:
        pass
        #print('Current Bones',i.name)
    print([i.name for i in arm.pose.bones])
    for item in esk.bones:
        current_Bone = arm.pose.bones[item.name]
        if "Hand" in item.name:
            current_Bone.rotation_quaternion.w = -0.707106
            current_Bone.rotation_quaternion.x = 0.707108
        #current_Bone.scale = item.SCA[0:3]
        #if len(current_Bone.children) > 0:
        #print(item.ORI)
        #print(current_Bone.tail)

        #print(item.ORI[0],item.ORI[1],item.ORI[2],item.ORI[3])

        ##current_Bone.rotation_quaternion.w = item.ORI[0]
        ##current_Bone.rotation_quaternion.x = item.ORI[1]
        ##current_Bone.rotation_quaternion.y = -item.ORI[2]
        ##current_Bone.rotation_quaternion.z = -item.ORI[3]
        # = item.ORI
        #print(current_Bone.tail)
        #print(current_Bone.rotation_quaternion)
        #print(current_Bone.rotation_euler)

    #    #print()




    bpy.data.objects[esk.name].rotation_euler[0] = 1.5708
    bpy.data.objects[esk.name].rotation_euler[2] = -1.5708 * 2

    if emd_objects is not None:
        for i in emd_objects:
            ArmModName = 'Skin'
            i.modifiers.new(name=ArmModName,type='ARMATURE')
            i.modifiers[ArmModName].object = bpy.data.objects[esk.name]
    pass
