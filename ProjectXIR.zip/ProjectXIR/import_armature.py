from tkinter import filedialog

def browseFiles() -> str:
    print("Browsing Files")
    filename = filedialog.askopenfilename(initialdir = "C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/",
                                          title = "Select a File",
                                          filetypes = (("XenoRigs",
                                                        ".esk"),
                                                       ("all files",
                                                        "*.*")))
    return filename


#import bpy
from fileUtil import (str2hex,hex2str,hexify,fileReader,hexList2hexStrList,)
import re
from handlingHex import vertHex2Float,hex2float,hexToHalfFloat,hexToShort
from esk_file_obj import (EskArmature,
                           Bone)


#/*-------------------------------------------------------------------------------\#
#|              Locate Potential Words Found In charmap Decoded File              |#
#\-------------------------------------------------------------------------------*/#
def englishFilter(HEX):
    validEnglish = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890_'
    if type(HEX) == str:
        hSplit = HEX.split(' ')
    elif type(HEX) == list:
        hSplit = HEX
    tList = []
    tStr = ''
    for x in range(0,len(hSplit)):
        #print(validEnglish.__contains__(hex2str(hSplit[x])))
        if validEnglish.__contains__(hex2str(hSplit[x])):
            tStr+=hex2str(hSplit[x])
        else:
            if tStr != '' and len(tStr) > 1:
                tList.append(tStr)
                tStr = ''
            else:
                tStr = ''
    return tList




def fileSelector():
    userInput = int(input("1 for File Search\n2 for Preset File\n0 to quit"))
    if  userInput == 1:
        file = browseFiles()
        fileName = file[file.rindex('/')+1:]
        filePath = file.replace(fileName,'')
        return {"Path": filePath, "Name": fileName}
    elif userInput == 2:
        fileName = "GOK_000_hair_scd.esk"
        filePath = "C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK"
        return {"Path": filePath, "Name": fileName}
    elif userInput == 0:
        exit()
    else:
        print("Enter a specified Number next time dumbass")
        exit()

testFile = fileSelector()
fileBytes = fileReader(testFile["Path"], testFile["Name"])

def get_rig_hirearchy(HEX,tempArm):
    searchIn = HEX[:HEX.index('45 58 50 5f ')].lower()
    startFrom = searchIn.index('ff ff ') - searchIn.index('ff ff ')%(16*3)
    searchIn = searchIn[startFrom:]
    spare = None
    justInCase = None
    for x in range(0,len(searchIn),16*3):
        line = searchIn[x:x+(16*3)].split(' ')[:-1]
        #print(line)
        if line[3] == '00' and line[5] == '00' and line[11] == '00' and line[13] == '00' and x != 0:
            #print('Line 1+')
            #print(spare)
            if spare is not None:
                child = spare
                parent = hexToShort(line[4:6], True)
                if tempArm.bones[child].parent is None and child > parent:
                    #print("Spare  :",child, 'is a child of', parent)
                    tempArm.bones[child].parent = parent

            #print(line[4:6],line[8:10])
            if line[4:6] != ['ff','ff'] and line[8:10] != ['ff','ff']:
                child = hexToShort(line[8:10], True)
                parent = hexToShort(line[4:6], True)
                if tempArm.bones[child].parent is None and child > parent:
                    #print("First  :",child, 'is a child of', parent)
                    tempArm.bones[child].parent = parent

            #print(line[6:8],line[12:14])
            if line[6:8] != ['ff','ff'] and line[12:14] != ['ff','ff']:
                child =hexToShort(line[6:8],True)
                parent = hexToShort(line[12:14], True)
                if tempArm.bones[child].parent is None and child > parent:
                    #print("Second :",child, 'is a child of', parent)
                    tempArm.bones[child].parent = parent

            #print(line[6:8],line[8:10])
            if line[6:8] == ['ff','ff'] and line[8:10] != ['ff','ff']:
                child =hexToShort(line[8:10], True)
                parent = hexToShort(line[12:14], True)
                if tempArm.bones[child].parent is None and child > parent:
                    #print("Third  :",child, 'is a child of', parent)
                    tempArm.bones[child].parent = parent

            #print(line[0:2])
            #print(justInCase)
            if line[0:2] != ['ff','ff']:
                child = hexToShort(line[0:2], True)
                parent = justInCase
                if tempArm.bones[child].parent is None and child > parent:
                    #print('JIC    :',child, 'is a child of', parent)
                    tempArm.bones[child].parent = parent

            justInCase = hexToShort(line[12:14], True)
            if line[14:16] != ['ff','ff']:
                spare = hexToShort(line[14:16], True)
            else:
                spare = None
        elif x == 0:
            #print('Line 0')
            if line[6:8] != ['ff','ff'] and line[12:14] != ['ff','ff']:
                child = hexToShort(line[6:8], True)
                parent = hexToShort(line[12:14], True)
                #print(child, 'is a child of', parent)
                tempArm.bones[child].parent = parent
            justInCase = hexToShort(line[12:14], True)
            if line[14:16] != ['ff','ff']:
                spare = hexToShort(line[14:16], True)
            else:
                spare = None
        else:
            break

    #for bone2 in tempArm.bones:
    #    if bone2.parent is not None:
    #        print(tempArm.bones.index(bone2), bone2.name,'\t\t' + ' '*(30-(len(str(tempArm.bones.index(bone2)))+1+len(bone2.name))), bone2.parent, tempArm.bones[bone2.parent].name)
    #    else:
    #        print(tempArm.bones.index(bone2), bone2.name, '\t\t' + ' '*(30-(len(str(tempArm.bones.index(bone2)))+1+len(bone2.name))), bone2.parent)
    pass

def get_bone_names(HEX: str):
    hexList = HEX.split(' ')
    boneKeys = ['5f 78 5f ', '5f 4c 5f', '5f 52 5f', '5f 43 5f', '53 43 44 5f', '45 58 50 5f ','30 30 30 5f ','5f 54 5f ']
    boneOffset = int(HEX.index("45 58 50 5f ") / 3)
    tList = hexList[boneOffset:]
    tempWords = []
    word = ''
    for CurIndex in range(0, len(tList)):
        #print(hex2str(word), tList[CurIndex])
        if tList[CurIndex] != '00':
            word += tList[CurIndex] + ' '
            pass
        else:
            if CurIndex + 1 < len(tList):
                if tList[CurIndex + 1] != '00':
                    for item in boneKeys:
                        if item in word:
                            tempWords.append(hex2str(word))
                            word = ''
                            break
                    pass
                else:
                    for item in boneKeys:
                        if item in word:
                            tempWords.append(hex2str(word))
                            word = ''
                            break

                    #print('bonjour')
                    break
    return tempWords


fileHex = hexify(fileBytes)
hexList = fileHex.split(' ')

tempRig = EskArmature()

tempBoneList =  []
boneNames = get_bone_names(fileHex)
print(boneNames)
for name in boneNames:
    newBone = Bone()
    newBone.name = name
    tempRig.bones.append(newBone)

#for bone in tempRig.bones:
#    print(bone.name)


get_rig_hirearchy(fileHex,tempRig)


#print(boneNames)
#print(len(boneNames))
#print()
nema = str2hex(tempRig.bones[-1].name)
HexRow = int((int((fileHex.index(nema)+len(nema))/3)+1)/16)
StartPos = (HexRow+1)*16
print()
rowCount = 1
for i in range(StartPos,len(fileHex.split(' ')[StartPos:]),16*3):
    if rowCount > len(tempRig.bones):
        break
    curBone = tempRig.bones[rowCount - 1]
    posline = fileHex.split(' ')[i           :i + (16 * 1)]
    curBone.XYZ = [hex2float(posline[0:4]), hex2float(posline[4:8]), hex2float(posline[8:12])]
    oriline = fileHex.split(' ')[i + 16:i + (16 * 2)]
    curBone.ORI = [hex2float(oriline[0:4]),hex2float(oriline[4:8]),hex2float(oriline[8:12]),hex2float(oriline[12:16])]
    scaline = fileHex.split(' ')[i + (16 * 2):i + (16 * 3)]
    curBone.scale = [hex2float(scaline[0:4]),hex2float(scaline[4:8]),hex2float(scaline[8:12])]
    rowCount+=1

StartPos += rowCount*(16*3)
rowCount = 1
for i in range(StartPos, len(fileHex.split(' ')), 16 * 4):
    if rowCount > len(tempRig.bones):
        break
    curBone = tempRig.bones[rowCount - 1]
    Line1 = fileHex.split(' ')[i:i + (16 * 1)]
    curBone.ATML1 = [hex2float(Line1[0:4]), hex2float(Line1[4:8]), hex2float(Line1[8:12]),hex2float(Line1[12:16])]
    Line2 = fileHex.split(' ')[i + 16:i + (16 * 2)]
    curBone.ATML2 = [hex2float(Line2[0:4]), hex2float(Line2[4:8]), hex2float(Line2[8:12]), hex2float(Line2[12:16])]
    Line3 = fileHex.split(' ')[i + (16 * 2):i + (16 * 3)]
    curBone.ATML3 = [hex2float(Line3[0:4]), hex2float(Line3[4:8]), hex2float(Line3[8:12]), hex2float(Line3[12:16])]
    Line4 = fileHex.split(' ')[i + (16 * 3):i + (16 * 4)]
    curBone.ATML4 = [hex2float(Line4[0:4]), hex2float(Line4[4:8]), hex2float(Line4[8:12]), hex2float(Line4[12:16])]
    rowCount+=1

for item in tempRig.bones:
    print(item.name)
    print(item.XYZ,'\n'+str(item.ORI)+'\n'+str(item.scale))
    print()
    print(item.ATML1,'\n'+str(item.ATML2)+'\n'+str(item.ATML3)+'\n'+str(item.ATML4))
    print()


returnList = []

bones = []

for bone in range(0,len(tempRig.bones)):
    for i in ['armroll','hand', 'middle', 'ring', 'pinky', 'index', 'thumb']:

        pass
#for x in bones:
#    print(x.name, x.XYZ)
print(len(bones))
