import os
import fileUtil
from utilities import hexify
#with open(testPath + '/' + testFile, 'r') as f:
#    buff = f.read()
#print(buff)

# Broly:        4 after
# Goku Hair:    2 after
#
"""def hexIndexPrint(__hexList, __line, __lineIndex, __hexIndex=''):
    hexOutput = '00'
    __Table = {0: "0", 1: "1", 2: "2", 3: "3", 4: "4", 5: "5", 6: "6", 7: "7", 8: "8", 9: "9", 10: "a", 11: "b",
               12: "c", 13: "d", 14: "e", 15: "f"}
    if __hexIndex == '':
        print(__hexList[__line][__lineIndex])
        print(__Table[__lineIndex])

        pass
        print("0x"+hexOutput)
    else:
        pass
"""

vertOffset = 0x20dc
vertLHexCount = 4
vertTHexCount = 12
vertPadding = 24
#faceOffset = 0x0114
#faceLHexCount = 2
#faceTHexCount = 6
#facePadding = 0

#UVOffset = 0x20f0
#UVLHexCount = 2
#UVTHexCount = 4
#UVPadding = 32

valid_english = ['a',
'b',
'c',
'd',
'e',
'f',
'g',
'h',
'i',
'j',
'k',
'l',
'm',
'n',
'o',
'p',
'q',
'r',
's',
't',
'u',
'v',
'w',
'x',
'y',
'z',
'A',
'B',
'C',
'D',
'E',
'F',
'G',
'H',
'I',
'J',
'K',
'L',
'M',
'N',
'O',
'P',
'Q',
'R',
'S',
'T',
'U',
'V',
'W',
'X',
'Y',
'Z',
'0',
'1',
'2',
'3',
'4',
'5',
'6',
'7',
'8',
'9',
'_']



txtPath = 'C:/Users/Christopher Tully/Desktop'
txtFile = 'GOKLists.txt'
testPath = "C:/Users/Christopher Tully/Desktop/Dragon Ball Game Editor/chara/GOK"
testFile = "GOK_000_hair_scd.emd"

data = fileUtil.fileReader(testPath,testFile).decode('charmap')
temp = ''
for x in data:
    if x in valid_english:
        temp += x
    else:
        temp = ''

#print()



fileBytes = fileUtil.fileReader(testPath, testFile)

file1Hex = hexify.rhex(fileBytes).split(' ')
x = vertOffset
vertices = []



while x < len(file1Hex):
    vert = file1Hex[x:x+vertTHexCount]
    xCoor = vert[0:4]
    yCoor = vert[4:8]
    zCoor = vert[8:12]
    vertices.append([xCoor,yCoor,zCoor])
    x+=vertPadding+vertTHexCount
#for x in vertices:
#    print(x)



exit()

vertValEndList = []
vertices.remove(vertices[len(vertices)-1])
for v in vertices:
    print(int(v[0][3],16),int(v[1][3],16),int(v[2][3],16))




#hex_list = ["{:02x}".format(ord(c)) for c in file]
##print(hex_list)
#hexInd = 0

"""
4C EB 95 3D
AB 98 25 3C
0D A0 E9 3C
"""
vertices = []
faces = []


#hexIndexPrint(hexList,0,0)

