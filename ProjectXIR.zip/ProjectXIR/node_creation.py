import bpy
from .parameter_types import Parameter, params




def new_parameter():
    Parameter.new()
    pass