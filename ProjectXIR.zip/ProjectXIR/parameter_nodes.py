import bpy
import re
import os


from .node_templates import Parameter



class GenerateNode_OT_operator(bpy.types.Operator):
    bl_label = "Generate Node"
    bl_idname = "node.gen_node"

    @classmethod
    def poll(cls, context):
        try:
            return 'GROUP' == context.object.active_material.node_tree.nodes.active.type
        except:
            pass
    def execute(self, context):
        active_tree = context.object.active_material.node_tree
        node = active_tree.nodes.active
        if 'VALUE' == node.type:
            print('class '+node.label.replace(' ','_')+':')
            print('\tdef __init__(self,tree):')
            print('\t\tnode = tree.nodes.new(\'ShaderNodeValue\')')
            print('\t\tnode.name = \''+node.label.replace(' ','_')+'\'')
            print('\t\tnode.label = \''+node.label.replace(' ','_')+'\'')
            print('\t\tnode.outputs[0].default_value = '+str(node.outputs[0].default_value))
            print()
        elif 'FRAME' == node.type:
            print('class ' + node.label.replace(' ', '_') + ':')
            print('\tdef __init__(self,tree):')
            print('\t\tframe = tree.nodes.new(\'NodeFrame\')')
            node_index = 0
            for check_node in active_tree.nodes:
                if check_node.parent == node:
                    print('\t\tnode_'+str(node_index)+' = '+'tree.nodes.new(\'ShaderNodeValue\')')
                    print('\t\tnode_' + str(node_index) + ' = ' + 'tree.nodes.new(\'ShaderNodeValue\')')
                pass
            pass
        else:
            group_tree = node.node_tree
            # =======Generates Node Template======= #
            if True:
                text_file_lines = []
                # ============Creates Node Tree============ #
                print('class '+node.label.replace(' ','_')+':')
                print('\tdef __init__(self,tree):')
                print('\t\ttest_group = bpy.data.node_groups.new(\''+node.label.replace(' ','_')+'\', \'ShaderNodeTree\')')
                #print('\t\tgroup_in = test_group.nodes.new(\'NodeGroupInput\')\n\t\tgroup_out = test_group.nodes.new(\'NodeGroupOutput\')')
                print()
                # ============Node Declaration============ #
                node_ind = 0
                new_nodes = {}
                for item in group_tree.nodes:
                    new_nodes.__setitem__('inner_node_%i' % node_ind, item)
                    print('\t\tinner_node_%i' % node_ind
                          +' = test_group.nodes.new(\''+
                          str(item.bl_rna)[str(item.bl_rna).index('\"')+1:
                                           str(item.bl_rna).rindex('\"')]+'\')')
                    if item.label != '':
                        print('\t\tinner_node_%i' % node_ind
                              +'.name = \''+item.label+'\'')
                    node_ind+=1

                print()
                # ============Adds Node Inputs============ #
                for IN in range(0,len(list(node.inputs))):
                    print('\t\ttest_group.inputs.new(\''+
                          str(node.inputs[IN].bl_rna)[
                            str(node.inputs[IN].bl_rna).index('\"') + 1:
                            str(node.inputs[IN].bl_rna).rindex('\"')]+'\', \''+str(node.inputs[IN].name)+'\')')
                    try:
                        print('\t\ttest_group.inputs[' + str(IN) + '].min_value = ' + str(
                            bpy.data.node_groups[group_tree.name].inputs[IN].min_value))
                        print('\t\ttest_group.inputs[' + str(IN) + '].max_value = ' + str(
                            bpy.data.node_groups[group_tree.name].inputs[IN].max_value))
                        print('\t\ttest_group.inputs[' + str(IN) + '].hide_value = ' + str(
                            bpy.data.node_groups[group_tree.name].inputs[IN].hide_value))
                    except:
                        pass
                print()
                # ============Adds Node Outputs============ #
                for OUT in node.outputs:
                    print('\t\ttest_group.outputs.new(\'' +
                          str(OUT.bl_rna)[str(OUT.bl_rna).index('\"') + 1:
                                          str(OUT.bl_rna).rindex('\"')] + '\', \'' + OUT.name + '\')')
                print()
                # ============Assigns Node Locations============ #
                for item in new_nodes.keys():
                    print('\t\t'+item+'.location = '+ str(tuple(new_nodes[item].location)))
                print()
                # ============Creates Node Links============ #
                nodes = [new_nodes[it] for it in new_nodes.keys()]
                for link in group_tree.links:
                    _in  = list([new_nodes[_node] for _node in new_nodes][nodes.index(link.to_node)].inputs).index(link.to_socket)
                    _out = list([new_nodes[_node] for _node in new_nodes][nodes.index(link.from_node)].outputs).index(link.from_socket)
                    print('\t\ttest_group.links.new('+
                          list(new_nodes.keys())[nodes.index(link.to_node)]+'.inputs['+
                          str(_in) +']'+', '+
                          list(new_nodes.keys())[nodes.index(link.from_node)]+'.outputs['+
                          str(_out) +']'+')')
                print()
                # ============Assigns Default Values============ #      Aside from inputs and outputs
                for nod in new_nodes.keys():
                    if 'NodeGroupInput' not in str(new_nodes[nod].bl_rna) and 'NodeGroupOutput' not in str(new_nodes[nod].bl_rna):
                        for IN in range(0,len(new_nodes[nod].inputs)):
                            if 'NodeSocketShader' not in str(new_nodes[nod].inputs[IN].bl_rna):
                                try:
                                    #print(eval())
                                    print('\t\t'+nod + '.inputs[' + str(IN) + '].default_value = ' + str(tuple([i for i in new_nodes[nod].inputs[IN].default_value])))
                                except:
                                    print('\t\t'+nod + '.inputs[' + str(IN) + '].default_value = ' + str(new_nodes[nod].inputs[IN].default_value))
                        for OUT in range(0,len(new_nodes[nod].outputs)):
                            if 'NodeSocketShader' not in str(new_nodes[nod].outputs[OUT].bl_rna):
                                try:
                                    print('\t\t'+nod + '.outputs[' + str(OUT) + '].default_value = ' + str(tuple([i for i in new_nodes[nod].outputs[OUT].default_value])))
                                except:
                                    print('\t\t'+nod + '.outputs[' + str(OUT) + '].default_value = ' + str(new_nodes[nod].outputs[OUT].default_value))
                        print()
                # ============Assign Inner Node Functionality Types============ #

                for nod in new_nodes.keys():
                    for ite in new_nodes[nod].bl_rna.properties.keys():
                        if ite not in ['bl_idname',
                                       'bl_label',
                                       'bl_icon',
                                       'bl_static_type',
                                       'type',
                                       'dimensions',
                                       'show_options',
                                       'color',
                                       'select',
                                       'bl_width_default',
                                       'bl_width_min',
                                       'bl_width_max',
                                       'bl_height_default',
                                       'bl_height_min',
                                       'bl_height_max',
                                       ]:
                            try:
                                eval('new_nodes[nod].bl_rna.properties[\'' + ite + '\'].default')
                                #print('Value 1: ',eval('new_nodes[nod].bl_rna.properties[\''+ite+'\'].default'))
                                #print('Value 2: ',eval('new_nodes[nod].bl_rna.properties[\''+ite+'\'].default'), eval('new_nodes[nod]'+'.'+ite))
                                if eval('new_nodes[nod].bl_rna.properties[\''+ite+'\'].default') != eval('new_nodes[nod]'+'.'+ite):
                                    if type(eval('new_nodes[nod]'+'.'+ite)) == str:
                                        print('\t\t'+nod+'.'+ite+' = \''+str(eval('new_nodes[nod]'+'.'+ite))+'\'')
                                    elif type(eval('new_nodes[nod]'+'.'+ite)) == float or \
                                            type(eval('new_nodes[nod]'+'.'+ite)) == int or \
                                            type(eval('new_nodes[nod]'+'.'+ite)) == bool:
                                        print('\t\t'+nod+'.'+ite+' = '+str(eval('new_nodes[nod]'+'.'+ite)))
                                    else:
                                        print('\t\t'+nod+'.'+ite+' = '+str(tuple(eval('new_nodes[nod]'+'.'+ite))))

                            except:
                                pass#print('Error')

                    #print('\t\t'+nod+'.blend_type = \''+str(new_nodes[nod].blend_type)+'\'')

                print()
                # ============Creates The Group Node============ #
                print('\t\tnode = tree.nodes.new(\'ShaderNodeGroup\')')
                print('\t\tnode.label = \''+node.label+'\'')
                print('\t\tnode.node_tree = bpy.data.node_groups[test_group.name]')
                print('\t\tnode.width = '+str(node.width))
                print()
                for inp in range(0,len(list(node.inputs))):
                    if not bpy.data.node_groups[group_tree.name].inputs[inp].hide_value:
                        try:
                            print('\t\tnode.inputs['+str(inp)+'] = ' +str(tuple([k for k in node.inputs[inp].default_value])))
                        except:
                            print('\t\tnode.inputs['+str(inp)+'].default_value = '+str(node.inputs[inp].default_value))
                print()
                print('\t\tself.__node = node')
                print('\t\tpass')
                print('\tdef node(self):')
                print('\t\treturn self.__node')
                print('\tpass')
                pass
        print('\n'*3)
        # =======Generates Node Operator======= #
        if True:
            print('class '+node.label.replace(' ','')+'Node_OT_operator(bpy.types.Operator):')
            print('\tbl_label = \''+node.label+'\'')
            print('\tbl_idname = \'node.'+node.label.lower().replace(' ','_')+'\'')
            print('\t@classmethod')
            print('\tdef poll(cls,context):')
            print('\t\tnodes = [item.label for item in context.object.active_material.node_tree.nodes]')
            print('\t\treturn \''+node.label+'\' not in nodes')
            print()
            print('\tdef execute(self, context):')
            print('\t\tParameter.new(\''+node.label.replace(' ','_')+'\',context.object.active_material.node_tree)')
            print('\t\treturn {\'FINISHED\'}')
        print('\n' * 3)
        # =======Node Operator Call Line======= #
        print('other_nodes.operator(\'node.'+node.label.lower().replace(' ','_')+'\')')
        print('\n' * 3)

        #path = str(os.getcwd()).replace('\\', '/') + '/2.91/scripts/addons/XenoverseIR/Generated_Nodes'
        #try:
        #    text_file = open(path + '/' + node.label+'.txt','w+')
        #    text_file.writelines(text_file_lines)
        #except PermissionError as err:
        #    print(err)

        self.report({'INFO'}, "Node Generated!")
        return {'FINISHED'}

class GenNode_PT_panel(bpy.types.Panel):
    """Creates a Panel in the Node properties window"""
    bl_label = "Gen"
    bl_idname = "GenNode_PT_panel"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "XeNodes"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator('node.gen_node')

class XenoverseNodes_PT_panel(bpy.types.Panel):
    """Creates a Panel in the Node properties window"""
    bl_label = "Xenoverse Parameters"
    bl_idname = "XenoverseNodes_PT_panel"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "XeNodes"

    def draw(self, context):
        layout = self.layout

        ParaNodes = layout.box()
        ParaNodes.label(text="Parameter Nodes")
        oof = ParaNodes.row()

        ParaNodes.operator('node.matcol0')
        ParaNodes.operator('node.matcol1')
        ParaNodes.operator('node.matcol2')
        ParaNodes.operator('node.matcol3')
        ParaNodes.operator('node.texscrl0')
        ParaNodes.operator('node.matscale0')
        ParaNodes.operator('node.matscale1')





        other_nodes = layout.box()
        other_nodes.label(text="Other Nodes")
        other_nodes.operator('node.lighting')
        other_nodes.operator('node.combine_matcol')
        other_nodes.operator('node.dyt_strip_assigner')
        other_nodes.operator('node.merge_dyt')
        other_nodes.operator('node.xenoverse_shader_out')
        other_nodes.operator('node.matcol_plus_dyt')
        other_nodes.operator('node.combine_matcol_shadever')


        other_nodes.operator('node.line_work_image')
        other_nodes.operator('node.dyt_image')
        
        #other_nodes.operator('node.misc')



#=================Parameter Nodes=================#
class MatCol0Node_OT_operator(bpy.types.Operator):
    """Add MatCol0 Node (Used for Linework coloring)"""
    bl_label = 'MatCol0'
    bl_idname = 'node.matcol0'

    @classmethod
    def poll(cls,context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'MatCol0' not in nodes

    def execute(self, context):
        Parameter.new('MatCol0',context.object.active_material.node_tree)
        return {'FINISHED'}

class MatCol1Node_OT_operator(bpy.types.Operator):
    bl_label = 'MatCol1'
    bl_idname = 'node.matcol1'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'MatCol1' not in nodes

    def execute(self, context):
        Parameter.new('MatCol1',context.object.active_material.node_tree)
        #self.report({'INFO'}, "Yet To Be Implemented!")
        return {'FINISHED'}

class MatCol2Node_OT_operator(bpy.types.Operator):
    bl_label = 'MatCol2'
    bl_idname = 'node.matcol2'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'MatCol2' not in nodes

    def execute(self, context):
        Parameter.new('MatCol2',context.object.active_material.node_tree)
        return {'FINISHED'}

class MatCol3Node_OT_operator(bpy.types.Operator):
    bl_label = 'MatCol3'
    bl_idname = 'node.matcol3'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'MatCol3' not in nodes

    def execute(self, context):
        Parameter.new('MatCol3',context.object.active_material.node_tree)
        return {'FINISHED'}

class TexScrl0Node_OT_operator(bpy.types.Operator):
    bl_label = 'TexScrl0'
    bl_idname = 'node.texscrl0'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'TexScrl0' not in nodes

    def execute(self, context):
        Parameter.new('TexScrl0', context.object.active_material.node_tree)
        return {'FINISHED'}

class MatScale0Node_OT_operator(bpy.types.Operator):
    bl_label = 'MatScale0'
    bl_idname = 'node.matscale0'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'MatScale0' not in nodes

    def execute(self, context):
        Parameter.new('MatScale0', context.object.active_material.node_tree)
        return {'FINISHED'}

class MatScale1Node_OT_operator(bpy.types.Operator):
    bl_label = 'MatScale1'
    bl_idname = 'node.matscale1'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'MatScale1' not in nodes

    def execute(self, context):
        Parameter.new('MatScale1', context.object.active_material.node_tree)
        return {'FINISHED'}



#=================Misc Nodes=================#
class LightingNode_OT_operator(bpy.types.Operator):
    bl_label = 'Lighting'
    bl_idname = 'node.lighting'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'Lighting' not in nodes

    def execute(self, context):
        Parameter.new('Lighting', context.object.active_material.node_tree)
        return {'FINISHED'}

class ColorStripNode_OT_operator(bpy.types.Operator):
    bl_label = 'Color Strip'
    bl_idname = 'node.color_strip'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'Color Strip' not in nodes

    def execute(self, context):
        Parameter.new('Color Strip', context.object.active_material.node_tree)
        return {'FINISHED'}

class ShineNode_OT_operator(bpy.types.Operator):
    bl_label = 'Shine'
    bl_idname = 'node.shine'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'MatCol0' not in nodes

    def execute(self, context):
        Parameter.new('MatCol0', context.object.active_material.node_tree)
        return {'FINISHED'}

class CombineMatColNode_OT_operator(bpy.types.Operator):
    bl_label = 'Combine MatCol'
    bl_idname = 'node.combine_matcol'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'Combine_MatCol' not in nodes

    def execute(self, context):
        Parameter.new('Combine_MatCol', context.object.active_material.node_tree)
        return {'FINISHED'}

class LineWorkNode_OT_operator(bpy.types.Operator):
    """Add LineWork Node"""
    bl_label = 'Line Work Image'
    bl_idname = 'node.line_work_image'

    @classmethod
    def poll(cls,context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'Line Work Image' not in nodes

    def execute(self, context):
        Parameter.new('Line_Work_Image',context.object.active_material.node_tree)
        return {'FINISHED'}

class DYTNode_OT_operator(bpy.types.Operator):
    """Add DYT Image Node"""
    bl_label = 'DYT Image'
    bl_idname = 'node.dyt_image'

    @classmethod
    def poll(cls,context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'DYT Image' not in nodes

    def execute(self, context):
        Parameter.new('DYT_Image',context.object.active_material.node_tree)
        return {'FINISHED'}

class DYTStripAssignerNode_OT_operator(bpy.types.Operator):
    bl_label = 'DYT Strip Assigner'
    bl_idname = 'node.dyt_strip_assigner'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'DYT Strip Assigner' not in nodes

    def execute(self, context):
        Parameter.new('DYT_Strip_Assigner', context.object.active_material.node_tree)
        return {'FINISHED'}

class MergeDYTNode_OT_operator(bpy.types.Operator):
    bl_label = 'Merge DYT'
    bl_idname = 'node.merge_dyt'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'Merge DYT' not in nodes

    def execute(self, context):
        Parameter.new('Merge_DYT', context.object.active_material.node_tree)
        return {'FINISHED'}

class XenoverseShaderOutNode_OT_operator(bpy.types.Operator):
    bl_label = 'Xenoverse Shader Out'
    bl_idname = 'node.xenoverse_shader_out'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'Xenoverse Shader Out' not in nodes

    def execute(self, context):
        Parameter.new('Xenoverse_Shader_Out', context.object.active_material.node_tree)
        return {'FINISHED'}

class MatColPlusDYTNode_OT_operator(bpy.types.Operator):
    bl_label = 'MatCol Plus DYT'
    bl_idname = 'node.matcol_plus_dyt'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'MatCol Plus DYT' not in nodes

    def execute(self, context):
        Parameter.new('MatCol_Plus_DYT', context.object.active_material.node_tree)
        return {'FINISHED'}

class CombineMatColShadeVerNode_OT_operator(bpy.types.Operator):
    bl_label = 'Combine MatCol ShadeVer'
    bl_idname = 'node.combine_matcol_shadever'

    @classmethod
    def poll(cls, context):
        nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return 'Combine MatCol ShadeVer' not in nodes

    def execute(self, context):
        Parameter.new('Combine_MatCol_ShadeVer', context.object.active_material.node_tree)
        return {'FINISHED'}


class MiscNode_OT_operator(bpy.types.Operator):
    """Add DYT Image Node"""
    bl_label = 'Misc'
    bl_idname = 'node.misc'

    @classmethod
    def poll(cls,context):
        #nodes = [item.label for item in context.object.active_material.node_tree.nodes]
        return True

    def execute(self, context):
        print("Execute Misc Node")
        Parameter.new('UI_Testing',context.object.active_material.node_tree)
        return {'FINISHED'}
