import bpy

params = ['Glare','MatCol0','MatCol1','MatCol2','MatCol3','MatScale0','MatScale1','AlphaBlend','AlphaBlendType','TexScrl0','MatOffset1','ReflectCoeff','ReflectFresnelBias','ReflectFresnelCoeff','BackFace','MatC','MatOffset0','RimCoeff','RimPower','SpcCoeff','SpcPower','MarkSamplerAddress','ToonSamplerAddress','gLightAmb','gLightDif','gLightDir','gLightSpc','gToonTextureHeight','gToonTextureWidth','AlphaTest','NoEdge','g_MaterialOffset0_VS','GlareCol','LowRez','LowRezSmoke','ZWriteMask','CustomFlag','IncidenceAlphaBias','IncidencePower','VsFlag0','VsFlag1','VsFlag2','VsFlag3','AlphaSortMask','AnimationChannel','Billboard','BillboardType','TexScrl1','TwoSidedRender','MatSpc','MipMapLod0','MatAmb','MatAmbScale','MatDif','MatDifScale','MipMapLod1','TextureFilter0','TextureFilter2','FadeInit','FadeSpeed','GradientInit','GradientSpeed']

class AlphaBlend:
	def __init__(self):
		self.value_name = 'AlphaBlend'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class AlphaBlendType:
	def __init__(self):
		self.value_name = 'AlphaBlendType'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class AlphaSortMask:
	def __init__(self):
		self.value_name = 'AlphaSortMask'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class AlphaTest:
	def __init__(self):
		self.value_name = 'AlphaTest'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class AnimationChannel:
	def __init__(self):
		self.value_name = 'AnimationChannel'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class BackFace:
	def __init__(self):
		self.value_name = 'BackFace'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class Billboard:
	def __init__(self):
		self.value_name = 'Billboard'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class BillboardType:
	def __init__(self):
		self.value_name = 'BillboardType'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class CustomFlag:
	def __init__(self):
		self.value_name = 'CustomFlag'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class FadeInit:
	def __init__(self):
		self.value_name = 'FadeInit'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class FadeSpeed:
	def __init__(self):
		self.value_name = 'FadeSpeed'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class Glare:
	def __init__(self):
		self.value_name = 'Glare'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class GlareCol:
	def __init__(self):
		self.frame_name = 'GlareCol'

		self.values = {'GlareColR':0.0,
					   'GlareColG':0.0,
					   'GlareColB':0.0,
					   'GlareColA':0.0}

	def set_values(self, R=None, G=None, B=None, A=None):
		if R is not None:
			self.values['GlareColR'] = float(R)
		if G is not None:
			self.values['GlareColG'] = float(G)
		if B is not None:
			self.values['GlareColB'] = float(B)
		if A is not None:
			self.values['GlareColA'] = float(A)

class GradientInit:
	def __init__(self):
		self.value_name = 'GradientInit'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class GradientSpeed:
	def __init__(self):
		self.value_name = 'GradientSpeed'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class IncidenceAlphaBias:
	def __init__(self):
		self.value_name = 'IncidenceAlphaBias'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class IncidencePower:
	def __init__(self):
		self.value_name = 'IncidencePower'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class LowRez:
	def __init__(self):
		self.value_name = 'LowRez'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class LowRezSmoke:
	def __init__(self):
		self.value_name = 'LowRezSmoke'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class MarkSamplerAddress:
	def __init__(self):
		self.frame_name = 'MarkSamplerAddress'
		self.values = {'MarkSamplerAddressU':0.0,
					   'MarkSamplerAddressV':0.0}

	def set_values(self, U=None, V=None):
		if U is not None:
			self.values['MarkSamplerAddressU'] = float(U)
		if V is not None:
			self.values['MarkSamplerAddressV'] = float(V)

class MatAmb:
	def __init__(self):
		self.frame_name = 'MatAmb'

		self.values = {'MatAmbR':0.0,
					   'MatAmbG':0.0,
					   'MatAmbB':0.0,
					   'MatAmbA':0.0}

	def set_values(self, R=None, G=None, B=None, A=None):
		if R is not None:
			self.values['MatAmbR'] = float(R)
		if G is not None:
			self.values['MatAmbG'] = float(G)
		if B is not None:
			self.values['MatAmbB'] = float(B)
		if A is not None:
			self.values['MatAmbA'] = float(A)

class MatAmbScale:
	def __init__(self):
		self.value_name = 'MatAmbScale'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class MatC:
	def __init__(self):
		self.value_name = 'MatC'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class MatCol0:
	def __init__(self):
		self.frame_name = 'MatCol0'

		self.values = {'MatCol0R':0.0,
					   'MatCol0G':0.0,
					   'MatCol0B':0.0,
					   'MatCol0A':0.0}

	def set_values(self, R=None, G=None, B=None, A=None):
		if R is not None:
			self.values['MatCol0R'] = float(R)
		if G is not None:
			self.values['MatCol0G'] = float(G)
		if B is not None:
			self.values['MatCol0B'] = float(B)
		if A is not None:
			self.values['MatCol0A'] = float(A)

class MatCol1:
	def __init__(self):
		self.frame_name = 'MatCol1'

		self.values = {'MatCol1R':0.0,
					   'MatCol1G':0.0,
					   'MatCol1B':0.0,
					   'MatCol1A':0.0}

	def set_values(self, R=None, G=None, B=None, A=None):
		if R is not None:
			self.values['MatCol1R'] = float(R)
		if G is not None:
			self.values['MatCol1G'] = float(G)
		if B is not None:
			self.values['MatCol1B'] = float(B)
		if A is not None:
			self.values['MatCol1A'] = float(A)

class MatCol2:
	def __init__(self):
		self.frame_name = 'MatCol2'

		self.values = {'MatCol2R':0.0,
					   'MatCol2G':0.0,
					   'MatCol2B':0.0,
					   'MatCol2A':0.0}

	def set_values(self, R=None, G=None, B=None, A=None):
		if R is not None:
			self.values['MatCol2R'] = float(R)
		if G is not None:
			self.values['MatCol2G'] = float(G)
		if B is not None:
			self.values['MatCol2B'] = float(B)
		if A is not None:
			self.values['MatCol2A'] = float(A)

class MatCol3:
	def __init__(self):
		self.frame_name = 'MatCol3'

		self.values = {'MatCol3R':0.0,
					   'MatCol3G':0.0,
					   'MatCol3B':0.0,
					   'MatCol3A':0.0}

	def set_values(self, R=None, G=None, B=None, A=None):
		if R is not None:
			self.values['MatCol3R'] = float(R)
		if G is not None:
			self.values['MatCol3G'] = float(G)
		if B is not None:
			self.values['MatCol3B'] = float(B)
		if A is not None:
			self.values['MatCol3A'] = float(A)

class MatDif:
	def __init__(self):
		self.frame_name = 'MatDif'

		self.values = {'MatDifR':0.0,
					   'MatDifG':0.0,
					   'MatDifB':0.0,
					   'MatDifA':0.0}

	def set_values(self, R=None, G=None, B=None, A=None):
		if R is not None:
			self.values['MatDifR'] = float(R)
		if G is not None:
			self.values['MatDifG'] = float(G)
		if B is not None:
			self.values['MatDifB'] = float(B)
		if A is not None:
			self.values['MatDifA'] = float(A)

class MatDifScale:
	def __init__(self):
		self.value_name = 'MatDifScale'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class MatOffset0:
	def __init__(self):
		self.frame_name = 'MatOffset0'
		self.values = {'MatOffset0X':0.0,
					   'MatOffset0Y':0.0,
					   'MatOffset0Z':0.0,
					   'MatOffset0W':0.0}

	def set_values(self, X=None, Y=None, Z=None, W=None):
		if X is not None:
			self.values['MatOffset0X'] = X
		if Y is not None:
			self.values['MatOffset0Y'] = Y
		if Z is not None:
			self.values['MatOffset0Z'] = Z
		if W is not None:
			self.values['MatOffset0W'] = W

class MatOffset1:
	def __init__(self):
		self.frame_name = 'MatOffset1'
		self.values = {'MatOffset1X':0.0,
					   'MatOffset1Y':0.0,
					   'MatOffset1Z':0.0,
					   'MatOffset1W':0.0}

	def set_values(self, X=None, Y=None, Z=None, W=None):
		if X is not None:
			self.values['MatOffset1X'] = X
		if Y is not None:
			self.values['MatOffset1Y'] = Y
		if Z is not None:
			self.values['MatOffset1Z'] = Z
		if W is not None:
			self.values['MatOffset1W'] = W

class MatScale0:
	def __init__(self):
		self.frame_name = 'MatScale0'
		self.values = {'MatScale0X':0.0,
					   'MatScale0Y':0.0,
					   'MatScale0Z':0.0,
					   'MatScale0W':0.0}

	def set_values(self, X=None, Y=None, Z=None, W=None):
		if X is not None:
			self.values['MatScale0X'] = X
		if Y is not None:
			self.values['MatScale0Y'] = Y
		if Z is not None:
			self.values['MatScale0Z'] = Z
		if W is not None:
			self.values['MatScale0W'] = W

class MatScale1:
	def __init__(self):
		self.frame_name = 'MatScale1'
		self.values = {'MatScale1X':0.0,
					   'MatScale1Y':0.0,
					   'MatScale1Z':0.0,
					   'MatScale1W':0.0}

	def set_values(self, X=None, Y=None, Z=None, W=None):
		if X is not None:
			self.values['MatScale1X'] = X
		if Y is not None:
			self.values['MatScale1Y'] = Y
		if Z is not None:
			self.values['MatScale1Z'] = Z
		if W is not None:
			self.values['MatScale1W'] = W

class MatSpc:
	def __init__(self):
		self.frame_name = 'MatSpc'

		self.values = {'MatSpcR':0.0,
					   'MatSpcG':0.0,
					   'MatSpcB':0.0,
					   'MatSpcA':0.0}

	def set_values(self, R=None, G=None, B=None, A=None):
		if R is not None:
			self.values['MatSpcR'] = float(R)
		if G is not None:
			self.values['MatSpcG'] = float(G)
		if B is not None:
			self.values['MatSpcB'] = float(B)
		if A is not None:
			self.values['MatSpcA'] = float(A)

class MipMapLod0:
	def __init__(self):
		self.value_name = 'MipMapLod0'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class MipMapLod1:
	def __init__(self):
		self.value_name = 'MipMapLod1'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class NoEdge:
	def __init__(self):
		self.value_name = 'NoEdge'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class ReflectCoeff:
	def __init__(self):
		self.value_name = 'ReflectCoeff'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class ReflectFresnelBias:
	def __init__(self):
		self.value_name = 'ReflectFresnelBias'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class ReflectFresnelCoeff:
	def __init__(self):
		self.value_name = 'ReflectFresnelCoeff'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class RimCoeff:
	def __init__(self):
		self.value_name = 'RimCoeff'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class RimPower:
	def __init__(self):
		self.value_name = 'RimPower'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class SpcCoeff:
	def __init__(self):
		self.value_name = 'SpcCoeff'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class SpcPower:
	def __init__(self):
		self.value_name = 'SpcPower'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class TexScrl0:
	def __init__(self):
		self.frame_name = 'TexScrl0'
		self.values = {'TexScrl0U':0.0,
					   'TexScrl0V':0.0}

	def set_values(self, U=None, V=None):
		if U is not None:
			self.values['TexScrl0U'] = float(U)
		if V is not None:
			self.values['TexScrl0V'] = float(V)

class TexScrl1:
	def __init__(self):
		self.frame_name = 'TexScrl1'
		self.values = {'TexScrl1U':0.0,
					   'TexScrl1V':0.0}

	def set_values(self, U=None, V=None):
		if U is not None:
			self.values['TexScrl1U'] = float(U)
		if V is not None:
			self.values['TexScrl1V'] = float(V)

class TextureFilter0:
	def __init__(self):
		self.value_name = 'TextureFilter0'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class TextureFilter2:
	def __init__(self):
		self.value_name = 'TextureFilter2'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class ToonSamplerAddress:
	def __init__(self):
		self.frame_name = 'ToonSamplerAddress'
		self.values = {'ToonSamplerAddressU':0.0,
					   'ToonSamplerAddressV':0.0}

	def set_values(self, U=None, V=None):
		if U is not None:
			self.values['ToonSamplerAddressU'] = float(U)
		if V is not None:
			self.values['ToonSamplerAddressV'] = float(V)

class TwoSidedRender:
	def __init__(self):
		self.value_name = 'TwoSidedRender'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class VsFlag0:
	def __init__(self):
		self.value_name = 'VsFlag0'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class VsFlag1:
	def __init__(self):
		self.value_name = 'VsFlag1'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class VsFlag2:
	def __init__(self):
		self.value_name = 'VsFlag2'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class VsFlag3:
	def __init__(self):
		self.value_name = 'VsFlag3'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class ZWriteMask:
	def __init__(self):
		self.value_name = 'ZWriteMask'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class gLightAmb:
	def __init__(self):
		self.value_name = 'gLightAmb'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class gLightDif:
	def __init__(self):
		self.value_name = 'gLightDif'
		self.value: float = \
			0.0
	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class gLightDir:
	def __init__(self):
		self.value_name = 'gLightDir'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class gLightSpc:
	def __init__(self):
		self.value_name = 'gLightSpc'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class gToonTextureHeight:
	def __init__(self):
		self.value_name = 'gToonTextureHeight'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class gToonTextureWidth:
	def __init__(self):
		self.value_name = 'gToonTextureWidth'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class g_MaterialOffset0_VS:
	def __init__(self):
		self.value_name = 'g_MaterialOffset0_VS'
		self.value: float = 0.0

	def set_values(self, Val=None):
		if Val is not None:
			self.value = Val

class Parameter:
	__options = {
		'Glare': Glare(),
		'MatCol0': MatCol0(),
		'MatCol1': MatCol1(),
		'MatCol2': MatCol2(),
		'MatCol3': MatCol3(),
		'MatScale0': MatScale0(),
		'MatScale1': MatScale1(),
		'AlphaBlend': AlphaBlend(),
		'AlphaBlendType': AlphaBlendType(),
		'TexScrl0': TexScrl0(),
		'MatOffset1': MatOffset1(),
		'ReflectCoeff': ReflectCoeff(),
		'ReflectFresnelBias': ReflectFresnelBias(),
		'ReflectFresnelCoeff': ReflectFresnelCoeff(),
		'BackFace': BackFace(),
		'MatC': MatC(),
		'MatOffset0': MatOffset0(),
		'RimCoeff': RimCoeff(),
		'RimPower': RimPower(),
		'SpcCoeff': SpcCoeff(),
		'SpcPower': SpcPower(),
		'MarkSamplerAddress': MarkSamplerAddress(),
		'ToonSamplerAddress': ToonSamplerAddress(),
		'gLightAmb': gLightAmb(),
		'gLightDif': gLightDif(),
		'gLightDir': gLightDir(),
		'gLightSpc': gLightSpc(),
		'gToonTextureHeight': gToonTextureHeight(),
		'gToonTextureWidth': gToonTextureWidth(),
		'AlphaTest': AlphaTest(),
		'NoEdge': NoEdge(),
		'g_MaterialOffset0_VS': g_MaterialOffset0_VS(),
		'GlareCol': GlareCol(),
		'LowRez': LowRez(),
		'LowRezSmoke': LowRezSmoke(),
		'ZWriteMask': ZWriteMask(),
		'CustomFlag': CustomFlag(),
		'IncidenceAlphaBias': IncidenceAlphaBias(),
		'IncidencePower': IncidencePower(),
		'VsFlag0': VsFlag0(),
		'VsFlag1': VsFlag1(),
		'VsFlag2': VsFlag2(),
		'VsFlag3': VsFlag3(),
		'AlphaSortMask': AlphaSortMask(),
		'AnimationChannel': AnimationChannel(),
		'Billboard': Billboard(),
		'BillboardType': BillboardType(),
		'TexScrl1': TexScrl1(),
		'TwoSidedRender': TwoSidedRender(),
		'MatSpc': MatSpc(),
		'MipMapLod0': MipMapLod0(),
		'MatAmb': MatAmb(),
		'MatAmbScale': MatAmbScale(),
		'MatDif': MatDif(),
		'MatDifScale': MatDifScale(),
		'MipMapLod1': MipMapLod1(),
		'TextureFilter0': TextureFilter0(),
		'TextureFilter2': TextureFilter2(),
		'FadeInit': FadeInit(),
		'FadeSpeed': FadeSpeed(),
		'GradientInit': GradientInit(),
		'GradientSpeed': GradientSpeed(),
	}
	@classmethod
	def new(cls,parameter_type: str):
		__options = {
			'Glare': Glare(),
			'MatCol0': MatCol0(),
			'MatCol1': MatCol1(),
			'MatCol2': MatCol2(),
			'MatCol3': MatCol3(),
			'MatScale0': MatScale0(),
			'MatScale1': MatScale1(),
			'AlphaBlend': AlphaBlend(),
			'AlphaBlendType': AlphaBlendType(),
			'TexScrl0': TexScrl0(),
			'MatOffset1': MatOffset1(),
			'ReflectCoeff': ReflectCoeff(),
			'ReflectFresnelBias': ReflectFresnelBias(),
			'ReflectFresnelCoeff': ReflectFresnelCoeff(),
			'BackFace': BackFace(),
			'MatC': MatC(),
			'MatOffset0': MatOffset0(),
			'RimCoeff': RimCoeff(),
			'RimPower': RimPower(),
			'SpcCoeff': SpcCoeff(),
			'SpcPower': SpcPower(),
			'MarkSamplerAddress': MarkSamplerAddress(),
			'ToonSamplerAddress': ToonSamplerAddress(),
			'gLightAmb': gLightAmb(),
			'gLightDif': gLightDif(),
			'gLightDir': gLightDir(),
			'gLightSpc': gLightSpc(),
			'gToonTextureHeight': gToonTextureHeight(),
			'gToonTextureWidth': gToonTextureWidth(),
			'AlphaTest': AlphaTest(),
			'NoEdge': NoEdge(),
			'g_MaterialOffset0_VS': g_MaterialOffset0_VS(),
			'GlareCol': GlareCol(),
			'LowRez': LowRez(),
			'LowRezSmoke': LowRezSmoke(),
			'ZWriteMask': ZWriteMask(),
			'CustomFlag': CustomFlag(),
			'IncidenceAlphaBias': IncidenceAlphaBias(),
			'IncidencePower': IncidencePower(),
			'VsFlag0': VsFlag0(),
			'VsFlag1': VsFlag1(),
			'VsFlag2': VsFlag2(),
			'VsFlag3': VsFlag3(),
			'AlphaSortMask': AlphaSortMask(),
			'AnimationChannel': AnimationChannel(),
			'Billboard': Billboard(),
			'BillboardType': BillboardType(),
			'TexScrl1': TexScrl1(),
			'TwoSidedRender': TwoSidedRender(),
			'MatSpc': MatSpc(),
			'MipMapLod0': MipMapLod0(),
			'MatAmb': MatAmb(),
			'MatAmbScale': MatAmbScale(),
			'MatDif': MatDif(),
			'MatDifScale': MatDifScale(),
			'MipMapLod1': MipMapLod1(),
			'TextureFilter0': TextureFilter0(),
			'TextureFilter2': TextureFilter2(),
			'FadeInit': FadeInit(),
			'FadeSpeed': FadeSpeed(),
			'GradientInit': GradientInit(),
			'GradientSpeed': GradientSpeed(),
		}
		return __options[parameter_type]